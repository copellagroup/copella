<?php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function() {
    add_menu_page(
        'CP Player',
        'CP Player',
        'manage_options',
        'cpplayer',
        'cpplayer_admin_page',
        'dashicons-video-alt3'
    );
    add_submenu_page(
        'cpplayer',
        'Настройки',
        'Настройки',
        'manage_options',
        'cpplayer-settings',
        'cpplayer_settings_page'
    );
    add_submenu_page(
        'cpplayer',
        'Видеоролики',
        'Видеоролики',
        'manage_options',
        'cpplayer_videos',
        'cpplayer_videos_page'
    );
    add_submenu_page(
        'cpplayer',
        'Массовое добавление записей (Бета)',
        'Массовое добавление (Бета)',
        'manage_options',
        'cpplayer_bulk_posts',
        'cpplayer_bulk_posts_page'
    );
    add_submenu_page(
        'cpplayer',
        'Массовая замена шорткодов',
        'Замена шорткодов',
        'manage_options',
        'cpplayer_bulk_shortcode_replace',
        'cpplayer_bulk_shortcode_replace_page'
    );
});

add_action('admin_init', function() {
    register_setting('cpplayer-settings-group', 'cpplayer_stub_video_url', ['type' => 'string', 'sanitize_callback' => 'esc_url_raw']);
    register_setting('cpplayer-settings-group', 'cpplayer_ad_skip_time', ['type' => 'number', 'sanitize_callback' => 'intval', 'default' => 5]);
    register_setting('cpplayer-settings-group', 'cpplayer_embed_page_id', ['type' => 'number', 'sanitize_callback' => 'intval']);

    if (isset($_POST['cpplayer_create_embed_page']) && check_admin_referer('cpplayer_create_embed_page_nonce')) {
        $page_id = wp_insert_post([
            'post_title' => __('CP Player Embed', 'cpplayer'),
            'post_name' => 'cpplayer-embed',
            'post_status' => 'publish',
            'post_type' => 'page',
            'page_template' => 'public/embed-template.php'
        ]);
        if ($page_id && !is_wp_error($page_id)) {
            update_option('cpplayer_embed_page_id', $page_id);
        }
        wp_redirect(admin_url('admin.php?page=cpplayer-settings&page_created=true'));
        exit;
    }
});

function cpplayer_handle_form_actions() {
    if (!isset($_GET['page']) || strpos($_GET['page'], 'cpplayer') === false) {
        return;
    }

    if (isset($_POST['cpplayer_add']) && check_admin_referer('cpplayer_add_nonce')) {
        $players = get_option('cpplayer_shortcodes', []);
        $id = uniqid('pl');
        $players[$id] = [
            'title' => sanitize_text_field($_POST['cpplayer_title'] ?? ''),
            'src' => esc_url_raw($_POST['cpplayer_src'] ?? ''),
            'type' => $_POST['cpplayer_type'] ?? 'video',
            'author' => !empty($_POST['cpplayer_author']) ? sanitize_text_field($_POST['cpplayer_author']) : '',
            'image' => !empty($_POST['cpplayer_image']) ? esc_url_raw($_POST['cpplayer_image']) : '',
            'radio_logo' => !empty($_POST['cpplayer_radio_logo']) ? esc_url_raw($_POST['cpplayer_radio_logo']) : ''
        ];
        update_option('cpplayer_shortcodes', $players);
        wp_redirect(admin_url('admin.php?page=cpplayer&action_result=added'));
        exit;
    }
    
    if (isset($_GET['cpplayer_delete'])) {
        $id = sanitize_text_field($_GET['cpplayer_delete']);
        check_admin_referer('cpplayer_delete_' . $id);
        $players = get_option('cpplayer_shortcodes', []);
        unset($players[$id]);
        update_option('cpplayer_shortcodes', $players);
        wp_redirect(admin_url('admin.php?page=cpplayer&action_result=deleted'));
        exit;
    }

    if (isset($_POST['cpplayer_edit']) && check_admin_referer('cpplayer_edit_nonce')) {
        $players = get_option('cpplayer_shortcodes', []);
        $id = sanitize_text_field($_POST['cpplayer_id']);
        if (isset($players[$id])) {
            $players[$id]['title'] = sanitize_text_field($_POST['cpplayer_title'] ?? '');
            $players[$id]['src'] = esc_url_raw($_POST['cpplayer_src'] ?? '');
            $players[$id]['type'] = $_POST['cpplayer_type'] ?? 'video';
            $players[$id]['author'] = !empty($_POST['cpplayer_author']) ? sanitize_text_field($_POST['cpplayer_author']) : '';
            $players[$id]['image'] = !empty($_POST['cpplayer_image']) ? esc_url_raw($_POST['cpplayer_image']) : '';
            $players[$id]['radio_logo'] = !empty($_POST['cpplayer_radio_logo']) ? esc_url_raw($_POST['cpplayer_radio_logo']) : '';
            update_option('cpplayer_shortcodes', $players);
            
            $base_url = admin_url('admin.php?page=cpplayer');
            $query_args = [];
            foreach (['search', 'type', 'sort', 'order'] as $key) {
                if (!empty($_GET[$key])) {
                    $query_args[$key] = urlencode(stripslashes($_GET[$key]));
                }
            }
            $query_args['action_result'] = 'updated';

            wp_redirect(add_query_arg($query_args, $base_url));
            exit;
        }
    }
}
add_action('admin_init', 'cpplayer_handle_form_actions');

function cpplayer_settings_page() {
    if (!current_user_can('manage_options')) return;

    if (isset($_GET['page_created'])) {
        echo '<div class="updated"><p>' . __('Страница для встраивания была успешно создана.', 'cpplayer') . '</p></div>';
    }

    $embed_page_id = get_option('cpplayer_embed_page_id');
    $embed_page_url = $embed_page_id ? get_permalink($embed_page_id) : null;
    ?>
    <div class="wrap">
        <h1>Настройки CP Player</h1>
        <form method="post" action="options.php">
            <?php
                settings_fields('cpplayer-settings-group');
                do_settings_sections('cpplayer-settings-group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row"><label for="cpplayer_stub_video_url">URL видео-заглушки для потоков</label></th>
                    <td>
                        <input type="url" id="cpplayer_stub_video_url" name="cpplayer_stub_video_url" value="<?php echo esc_attr(get_option('cpplayer_stub_video_url', '')); ?>" class="regular-text" />
                        <p class="description">Это видео будет проигрываться в цикле, если прямой эфир недоступен. Оставьте пустым, чтобы отключить.</p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><label for="cpplayer_ad_skip_time">Время до пропуска рекламы (сек)</label></th>
                    <td>
                        <input type="number" id="cpplayer_ad_skip_time" name="cpplayer_ad_skip_time" value="<?php echo esc_attr(get_option('cpplayer_ad_skip_time', 5)); ?>" class="small-text" min="0" />
                        <p class="description">Через сколько секунд после начала рекламы появится кнопка "Пропустить". Укажите 0, чтобы кнопка была доступна сразу.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>

        <hr>

        <h2><?php _e('Встраивание плеера', 'cpplayer'); ?></h2>
        <div id="cpplayer-embed-section">
            <?php if ($embed_page_url) : ?>
                <p><?php _e('Используйте форму ниже для генерации кода iframe.', 'cpplayer'); ?></p>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="embed_video_src"><?php _e('URL видео/потока', 'cpplayer'); ?></label></th>
                        <td><input type="url" id="embed_video_src" class="regular-text" placeholder="https://example.com/video.m3u8"></td>
                    </tr>
                    <tr valign="top">
                        <th scope="row"><label for="embed_code"><?php _e('Код для встраивания', 'cpplayer'); ?></label></th>
                        <td>
                            <textarea id="embed_code" rows="4" class="large-text" readonly></textarea>
                            <p class="description"><?php _e('Скопируйте этот код и вставьте его на свой сайт.', 'cpplayer'); ?></p>
                        </td>
                    </tr>
                </table>
                <p><strong><?php _e('URL страницы для встраивания:', 'cpplayer'); ?></strong> <code><?php echo esc_url($embed_page_url); ?></code></p>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const videoSrcInput = document.getElementById('embed_video_src');
                        const embedCodeTextarea = document.getElementById('embed_code');
                        const embedPageUrl = '<?php echo esc_js($embed_page_url); ?>';

                        function generateEmbedCode() {
                            const videoSrc = videoSrcInput.value;
                            if (videoSrc) {
                                const embedUrl = new URL(embedPageUrl);
                                embedUrl.searchParams.set('src', videoSrc);
                                embedCodeTextarea.value = `<iframe src="${embedUrl.href}" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>`;
                            } else {
                                embedCodeTextarea.value = '';
                            }
                        }

                        videoSrcInput.addEventListener('input', generateEmbedCode);
                    });
                </script>

            <?php else : ?>
                <p><?php _e('Чтобы встроить плеер, нужна выделенная страница. Нажмите кнопку ниже, чтобы создать ее автоматически.', 'cpplayer'); ?></p>
                <form method="post">
                    <?php wp_nonce_field('cpplayer_create_embed_page_nonce'); ?>
                    <button type="submit" name="cpplayer_create_embed_page" class="button button-primary"><?php _e('Создать страницу для встраивания', 'cpplayer'); ?></button>
                </form>
            <?php endif; ?>
        </div>

    </div>
    <?php
}

add_action('admin_enqueue_scripts', function($hook) {
    if (strpos($hook, 'cpplayer') === false) {
        return;
    }
    wp_enqueue_media();
    $ver = intval(get_option('cpplayer_cache_version', 1));
    wp_enqueue_style('cpplayer-admin-style', plugins_url('../public/assets/admin-styles.css', __FILE__), [], $ver);
});

function cpplayer_admin_page() {
    if (!current_user_can('manage_options')) return;

    if (isset($_GET['action_result'])) {
        $message = '';
        switch ($_GET['action_result']) {
            case 'added':
                $message = 'Плеер добавлен.';
                break;
            case 'deleted':
                $message = 'Плеер удалён.';
                break;
            case 'updated':
                $message = 'Плеер обновлён.';
                break;
        }
        if ($message) {
            echo '<div class="updated"><p>' . esc_html($message) . '</p></div>';
        }
    }

    $players = get_option('cpplayer_shortcodes', []);
    $all_videos = get_option('cpplayer_videos', []);
    $search = isset($_GET['search']) ? trim(sanitize_text_field($_GET['search'])) : '';
    $sort = isset($_GET['sort']) ? $_GET['sort'] : 'title';
    $order = isset($_GET['order']) && $_GET['order'] === 'desc' ? 'desc' : 'asc';
    $filter_type = isset($_GET['type']) ? $_GET['type'] : '';
    if ($filter_type && in_array($filter_type, ['video','stream','audio','radio'])) {
        $players = array_filter($players, function($pl) use ($filter_type) {
            return ($pl['type'] ?? '') === $filter_type;
        });
    }
    if ($search) {
        $search_lower = mb_strtolower($search);
        $players = array_filter($players, function($pl) use ($search_lower) {
            $title = $pl['title'] ?? '';
            $author = $pl['author'] ?? '';
            return (mb_strpos(mb_strtolower($title), $search_lower) !== false) || 
                   (mb_strpos(mb_strtolower($author), $search_lower) !== false);
        });
    }
    if ($sort === 'date') {
        if ($order === 'asc') {
            ksort($players);
        } else {
            krsort($players);
        }
    } else {
        uasort($players, function($a, $b) use ($order) {
            return $order === 'asc' ? strcasecmp($a['title'], $b['title']) : strcasecmp($b['title'], $a['title']);
        });
    }
    ?>
    <div class="wrap">
        <h1>CP Player</h1>

        <hr/>

        <form method="get" style="margin-bottom:18px;display:flex;gap:10px;align-items:end;">
            <input type="hidden" name="page" value="cpplayer">
            <label>Поиск: <input type="text" name="search" value="<?= esc_attr($search) ?>" placeholder="Название..."></label>
            <label>Тип:
                <select name="type">
                    <option value="">Все</option>
                    <option value="video"<?= $filter_type==='video'?' selected':'' ?>>Видео</option>
                    <option value="stream"<?= $filter_type==='stream'?' selected':'' ?>>Поток</option>
                    <option value="audio"<?= $filter_type==='audio'?' selected':'' ?>>Аудио</option>
                    <option value="radio"<?= $filter_type==='radio'?' selected':'' ?>>Радио</option>
                </select>
            </label>
            <label>Сортировка:
                <select name="sort">
                    <option value="title"<?= $sort==='title'?' selected':'' ?>>По названию</option>
                    <option value="date"<?= $sort==='date'?' selected':'' ?>>По дате</option>
                </select>
            </label>
            <select name="order">
                <option value="asc"<?= $order==='asc'?' selected':'' ?>>По возрастанию</option>
                <option value="desc"<?= $order==='desc'?' selected':'' ?>>По убыванию</option>
            </select>
            <button type="submit" class="button">Фильтровать</button>
            <button type="button" class="button" onclick="window.location.href='?page=cpplayer'">Сбросить</button>
        </form>
        <h2>Добавить новый плеер</h2>
        <p class="description" style="margin-bottom: 1em;">
            Видеоролики, добавленные в разделе <a href="?page=cpplayer_videos">"Видеоролики"</a>, будут автоматически применяться ко всем плеерам типа "Видео" и "Поток".
        </p>
        <form method="post">
            <?php wp_nonce_field('cpplayer_add_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="cpplayer_title">Название</label></th>
                    <td><input type="text" name="cpplayer_title" id="cpplayer_title" required></td>
                </tr>
                <tr>
                    <th><label for="cpplayer_src">Ссылка на видео/поток</label></th>
                    <td><input type="url" name="cpplayer_src" id="cpplayer_src" required></td>
                </tr>
                <tr>
                    <th><label for="cpplayer_type">Тип плеера</label></th>
                    <td>
                        <select name="cpplayer_type" id="cpplayer_type">
                            <option value="video">Видео</option>
                            <option value="stream">Поток</option>
                            <option value="audio">Аудио</option>
                            <option value="radio">Радио</option>
                        </select>
                    </td>
                </tr>
                <tr id="audio_fields" style="display:none;">
                    <th><label for="cpplayer_author">Автор</label></th>
                    <td><input type="text" name="cpplayer_author" id="cpplayer_author"></td>
                </tr>
                <tr id="audio_fields2" style="display:none;">
                    <th><label for="cpplayer_image">Обложка (URL)</label></th>
                    <td><input type="url" name="cpplayer_image" id="cpplayer_image"></td>
                </tr>
                <tr id="radio_fields" style="display:none;">
                    <th><label for="cpplayer_radio_logo">Логотип (URL)</label></th>
                    <td><input type="url" name="cpplayer_radio_logo" id="cpplayer_radio_logo"></td>
                </tr>
            </table>
            <p><input type="submit" name="cpplayer_add" class="button button-primary" value="Добавить"></p>
        </form>
        <h2>Существующие плееры</h2>
        <div class="cpplayer-cards">
            <?php 
            $edit_id = isset($_GET['cpplayer_edit']) ? sanitize_text_field($_GET['cpplayer_edit']) : null;
            foreach ($players as $id => $pl): ?>
                <?php
                $pl_type = $pl['type'] ?? 'video';
                ?>
                <div class="cpplayer-card" id="player-card-<?= esc_attr($id) ?>">
                <?php if ($edit_id === $id): ?>
                    <form method="post">
                        <?php wp_nonce_field('cpplayer_edit_nonce'); ?>
                        <div class="cpplayer-card-row"><label>Название:</label><input type="text" name="cpplayer_title" value="<?= esc_attr($pl['title']) ?>" required></div>
                        <div class="cpplayer-card-row"><label>Источник (src):</label><input type="url" name="cpplayer_src" value="<?= esc_attr($pl['src'] ?? '') ?>" required></div>
                        <div class="cpplayer-card-row"><label>Тип:</label>
                            <select name="cpplayer_type" id="cpplayer_type_edit_<?= esc_attr($id) ?>">
                                <option value="video"<?= $pl_type==='video'?' selected':'' ?>>Видео</option>
                                <option value="stream"<?= $pl_type==='stream'?' selected':'' ?>>Поток</option>
                                <option value="audio"<?= $pl_type==='audio'?' selected':'' ?>>Аудио</option>
                                <option value="radio"<?= $pl_type==='radio'?' selected':'' ?>>Радио</option>
                            </select>
                        </div>
                        <div class="cpplayer-card-row"<?= $pl_type!=='audio'?' style="display:none;"':'' ?> id="edit_audio_fields_<?= esc_attr($id) ?>"><label>Автор:</label><input type="text" name="cpplayer_author" value="<?= esc_attr($pl['author'] ?? '') ?>" placeholder="Автор"></div>
                        <div class="cpplayer-card-row"<?= $pl_type!=='audio'?' style="display:none;"':'' ?> id="edit_audio_fields2_<?= esc_attr($id) ?>"><label>Обложка (URL):</label><input type="url" name="cpplayer_image" value="<?= esc_attr($pl['image'] ?? '') ?>" placeholder="Обложка (URL)"></div>
                        <div class="cpplayer-card-row"<?= $pl_type!=='radio'?' style="display:none;"':'' ?> id="edit_radio_fields_<?= esc_attr($id) ?>"><label>Логотип (URL):</label><input type="url" name="cpplayer_radio_logo" value="<?= esc_attr($pl['radio_logo'] ?? '') ?>" placeholder="Логотип (URL)"></div>
                        <input type="hidden" name="cpplayer_id" value="<?= esc_attr($id) ?>">
                        <div class="cpplayer-card-actions">
                            <input type="submit" name="cpplayer_edit" class="button button-primary" value="Сохранить">
                            <a href="<?= admin_url('admin.php?page=cpplayer') ?>" class="button">Отмена</a>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="cpplayer-card-row">
                        <div class="cpplayer-card-title">
                            <a href="<?= admin_url('admin.php?page=cpplayer&cpplayer_edit=' . esc_attr($id)) ?>"><?= esc_html($pl['title']) ?></a>
                        </div>
                    </div>
                    <div class="cpplayer-card-row"><label>Шорткод:</label><code>[cpplayer id="<?= esc_attr($id) ?>"]</code></div>
                    <div class="cpplayer-card-row"><label>Источник (src):</label><code><?= esc_html($pl['src'] ?? '') ?></code></div>
                    <div class="cpplayer-card-row"><label>Тип:</label> <?= esc_html(ucfirst($pl['type'] ?? '')) ?></div>
                    <?php if ($pl_type === 'audio'): ?>
                    <div class="cpplayer-card-row"><label>Автор:</label> <?= esc_html($pl['author'] ?? '') ?></div>
                    <?php endif; ?>
                    
                    <?php 
                    $player_video_id = $pl['video_id'] ?? '';
                    if ($player_video_id && isset($all_videos[$player_video_id])): 
                    ?>
                        <div class="cpplayer-card-video"><b>Видеоролик:</b> <?= esc_html($all_videos[$player_video_id]['name']) ?></div>
                    <?php endif; ?>

                    <div class="cpplayer-card-actions">
                        <a href="<?= admin_url('admin.php?page=cpplayer&cpplayer_edit=' . esc_attr($id)) ?>" class="button button-secondary">Редактировать</a>
                        <?php $delete_url = wp_nonce_url(admin_url('admin.php?page=cpplayer&cpplayer_delete=' . esc_attr($id)), 'cpplayer_delete_' . esc_attr($id)); ?>
                        <a href="<?= esc_url($delete_url) ?>" class="button button-danger" onclick="return confirm('Вы уверены, что хотите удалить этот плеер?')">Удалить</a>
                        <button class="button cpplayer-copy-btn" data-clipboard-text="[cpplayer id=&quot;<?= esc_attr($id) ?>&quot;]">Копировать шорткод</button>
                    </div>
                <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var clipboard = new ClipboardJS('.cpplayer-copy-btn');
                clipboard.on('success', function(e) {
                    var originalText = e.trigger.textContent;
                    e.trigger.textContent = 'Скопировано!';
                    setTimeout(function() {
                        e.trigger.textContent = originalText;
                    }, 2000);
                    e.clearSelection();
                });

                const urlParams = new URLSearchParams(window.location.search);
                const editId = urlParams.get('cpplayer_edit');
                if (editId) {
                    const editCard = document.getElementById('player-card-' + editId);
                    if (editCard) {
                        editCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        // add some style to highlight the card
                        editCard.style.border = '2px solid #2271b1';
                        editCard.style.boxShadow = '0 0 10px rgba(34, 113, 177, 0.5)';
                    }
                }

                function toggleFields(select, idPrefix) {
                    const selectedType = select.value;
                    document.getElementById(idPrefix + 'audio_fields' + (select.id.includes('_edit_') ? '_' + select.id.split('_').pop() : '')).style.display = selectedType === 'audio' ? '' : 'none';
                    document.getElementById(idPrefix + 'audio_fields2' + (select.id.includes('_edit_') ? '_' + select.id.split('_').pop() : '')).style.display = selectedType === 'audio' ? '' : 'none';
                    document.getElementById(idPrefix + 'radio_fields' + (select.id.includes('_edit_') ? '_' + select.id.split('_').pop() : '')).style.display = selectedType === 'radio' ? '' : 'none';
                }

                const typeSelect = document.getElementById('cpplayer_type');
                if (typeSelect) {
                    typeSelect.addEventListener('change', function() {
                        toggleFields(this, '');
                    });
                    toggleFields(typeSelect, '');
                }

                document.querySelectorAll('select[id^="cpplayer_type_edit_"]').forEach(function(select) {
                    select.addEventListener('change', function() {
                        toggleFields(this, 'edit_');
                    });
                    toggleFields(select, 'edit_');
                });
            });
        </script>
        <style>
            .cpplayer-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
            .cpplayer-card { border: 1px solid #ccc; padding: 15px; border-radius: 5px; background: #fff; }
            .cpplayer-card-title a { font-size: 1.2em; text-decoration: none; font-weight: bold; }
            .cpplayer-card-row { margin-bottom: 10px; }
            .cpplayer-card-row label { font-weight: bold; }
            .cpplayer-card-row code { background: #eee; padding: 2px 5px; border-radius: 3px; }
            .cpplayer-card-actions { margin-top: 15px; display: flex; gap: 10px; flex-wrap: wrap; }
            .button-danger { background: #d9534f; border-color: #d43f3a; color: #fff; }
            .button-danger:hover { background: #c9302c; border-color: #ac2925; }
            .cpplayer-card form .cpplayer-card-row {
                display: flex;
                flex-direction: column;
            }
            .cpplayer-card form .cpplayer-card-row label {
                margin-bottom: 5px;
            }
            .cpplayer-card form input[type="text"],
            .cpplayer-card form input[type="url"],
            .cpplayer-card form select {
                width: 100%;
            }
            .cpplayer-card-ad, .cpplayer-card-video { padding: 8px; background: #f0f0f0; border-radius: 3px; margin-top: 10px; }
        </style>
    </div>
    <?php
}

function cpplayer_bulk_posts_page() {
    if (!current_user_can('manage_options')) return;
    $players = get_option('cpplayer_shortcodes', []);
    $categories = get_categories(['hide_empty'=>false]);
    $report = [];
    $all_tags = get_tags(['hide_empty'=>false]);
    $stati = get_post_stati(['internal'=>false], 'objects');
    $statuses = array_map(function($s){ return ['value'=>$s->name, 'label'=>$s->label]; }, $stati);

    
    if (isset($_POST['bulk_add']) && !empty($_POST['player_id'])) {
        $player_ids = $_POST['player_id'];
        $cat_ids = $_POST['category'] ?? [];
        $new_cats = $_POST['new_category'] ?? [];
        $tags_arr = $_POST['tags'] ?? [];
        $statuses_arr = $_POST['post_status'] ?? [];
        foreach ($player_ids as $i => $pid) {
            if (!isset($players[$pid])) continue;
            $cat_id = intval($cat_ids[$i] ?? 0);
            $new_cat = sanitize_text_field($new_cats[$i] ?? '');
            $tags = isset($tags_arr[$i]) ? array_map('intval', (array)$tags_arr[$i]) : [];
            $status = isset($statuses_arr[$i]) ? sanitize_text_field($statuses_arr[$i]) : 'publish';
            if ($new_cat) {
                $cat_obj = wp_insert_term($new_cat, 'category');
                if (!is_wp_error($cat_obj) && isset($cat_obj['term_id'])) {
                    $cat_id = $cat_obj['term_id'];
                }
            }
            $title = $players[$pid]['title'];
            $shortcode = '[cpplayer id="' . esc_attr($pid) . '"]';
            $post_data = [
                'post_title' => $title,
                'post_content' => $shortcode,
                'post_status' => $status,
                'post_category' => $cat_id ? [$cat_id] : [],
            ];
            $post_id = wp_insert_post($post_data);
            if ($post_id && !is_wp_error($post_id)) {
                if ($tags) wp_set_post_tags($post_id, $tags);
                $report[] = 'Запись <a href="' . get_edit_post_link($post_id) . '" target="_blank">' . esc_html($title) . '</a> создана.';
            } else {
                $report[] = 'Ошибка при создании записи для плеера: ' . esc_html($title);
            }
        }
    }
    ?>
    <div class="wrap">
        <h1>Массовое добавление записей <span style="color:#F658A4;font-size:0.7em;vertical-align:middle;">БЕТА</span></h1>
        <form method="post" style="max-width:700px;" id="cpplayer-bulk-add-form">
            <div id="cpplayer-bulk-blocks">
                <!-- JS вставит блоки -->
            </div>
            <button type="button" class="button" id="cpplayer-add-block-btn" style="margin:10px 0 20px 0;font-size:1.2em;">➕ Добавить запись</button>
            <br>
            <button type="submit" name="bulk_add" class="button button-primary">Создать записи</button>
        </form>
        <?php if ($report): ?>
            <div style="margin-top:18px;padding:12px 18px;background:#f7f7f7;border-radius:6px;">
                <b>Результат:</b><br>
                <?php foreach ($report as $msg) echo $msg . '<br>'; ?>
            </div>
        <?php endif; ?>
        <p style="margin-top:24px;color:#888;">Для каждой записи можно выбрать свой плеер, категорию, теги и статус.<br>Это <b>бета-функция</b>, используйте с осторожностью!</p>
        <script>
        const cpplayerPlayers = <?= json_encode($players) ?>;
        const cpplayerCategories = <?= json_encode(array_map(function($cat){return ['id'=>$cat->term_id,'name'=>$cat->name];}, $categories)) ?>;
        const cpplayerTags = <?= json_encode(array_map(function($tag){return ['id'=>$tag->term_id,'name'=>$tag->name];}, $all_tags)) ?>;
        const cpplayerStatuses = <?= json_encode($statuses) ?>;

        function createBulkBlock(idx) {
            
            const blockIndex = parseInt(idx, 10) || 0;
            return `
            <div class="cpplayer-bulk-block" style="border:1px solid #eee;background:#fafbfc;border-radius:8px;padding:16px 18px;margin-bottom:18px;position:relative;">
                <div style="position:absolute;top:10px;right:10px;">
                    <button type="button" class="button cpplayer-remove-block-btn">✖</button>
                </div>
                <div style="font-weight:bold;font-size:1.1em;margin-bottom:10px;">Запись #<span class="cpplayer-block-num">
                    ${blockIndex + 1}
                </span></div>
                <div style="margin-bottom:10px;">
                    <label>Плеер:<br>
                        <select name="player_id[]" required style="width:100%;max-width:400px;">
                            <option value="">-- Выбрать --</option>
                            ${Object.entries(cpplayerPlayers).map(([id,pl])=>`<option value="${id}">${pl.title.replace(/"/g,'&quot;')} [${id}]</option>`).join('')}
                        </select>
                    </label>
                </div>
                <div style="margin-bottom:10px;">
                    <label>Категория:<br>
                        <select name="category[]" style="width:100%;max-width:400px;">
                            <option value="0">-- Выбрать существующую --</option>
                            ${cpplayerCategories.map(cat=>`<option value="${cat.id}">${cat.name.replace(/"/g,'&quot;')}</option>`).join('')}
                        </select>
                        <span style="margin:0 8px;">или</span>
                        <input type="text" name="new_category[]" placeholder="Новая категория">
                    </label>
                </div>
                <div style="margin-bottom:10px;">
                    <label>Метки (теги):<br>
                        <select name="tags[${blockIndex}][]" multiple size="4" style="width:100%;max-width:400px;">
                            ${cpplayerTags.map(tag=>`<option value="${tag.id}">${tag.name.replace(/"/g,'&quot;')}</option>`).join('')}
                        </select>
                    </label>
                </div>
                <div style="margin-bottom:10px;">
                    <label>Статус:<br>
                        <select name="post_status[]" style="width:100%;max-width:400px;">
                            ${cpplayerStatuses.map(s=>`<option value="${s.value}"${s.value==='publish'?' selected':''}>${s.label}</option>`).join('')}
                        </select>
                    </label>
                </div>
            </div>`;
        }

        function cpplayerUpdateNumbers() {
            document.querySelectorAll('.cpplayer-bulk-block').forEach((block,i)=>{
                block.querySelector('.cpplayer-block-num').textContent = i+1;
                let tagsSelect = block.querySelector('select[name^="tags["]');
                if(tagsSelect) tagsSelect.name = `tags[${i}][]`;
            });
        }

        function cpplayerInitBulkAdd() {
            const addBtn = document.getElementById('cpplayer-add-block-btn');
            const blocksContainer = document.getElementById('cpplayer-bulk-blocks');
            if (addBtn && blocksContainer) { 
                let blockCounter = 0;
                function addNewBlock() {
                    const newBlockHTML = createBulkBlock(blockCounter); 
                    blocksContainer.insertAdjacentHTML('beforeend', newBlockHTML);
                    blockCounter++;
                    cpplayerUpdateNumbers(); 
                }
                addBtn.addEventListener('click', addNewBlock);
                if (!blocksContainer.querySelector('.cpplayer-bulk-block')) {
                    addNewBlock(); // Гарантируем стартовый блок
                }
            }
            document.addEventListener('click', function(e) {
                if (e.target && e.target.classList.contains('cpplayer-remove-block-btn')) {
                    const blockToRemove = e.target.closest('.cpplayer-bulk-block');
                    if (blockToRemove) {
                        blockToRemove.remove();
                        cpplayerUpdateNumbers();
                    }
                }
            });
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', cpplayerInitBulkAdd);
        } else {
            cpplayerInitBulkAdd();
        }

    });
    </script>
    <?php
}

function cpplayer_bulk_shortcode_replace_page() {
    if (!current_user_can('manage_options')) return;
    $players = get_option('cpplayer_shortcodes', []);
    $report = [];

    $search_term = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    $posts_per_page = 100;
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($paged - 1) * $posts_per_page;

    $query_args = [
        'post_type' => 'post',
        'post_status' => 'any',
        'posts_per_page' => $posts_per_page,
        'offset' => $offset,
        'orderby' => 'date',
        'order' => 'DESC',
        'fields' => 'all',
        's' => $search_term,
    ];

    $query = new WP_Query($query_args);
    $posts = $query->posts;
    $total_posts = $query->found_posts;
    $max_page = ceil($total_posts / $posts_per_page);

    if (isset($_POST['bulk_replace']) && !empty($_POST['block'])) {
        foreach ($_POST['block'] as $block_idx => $block) {
            $block_report = [];
            $post_ids = isset($block['post_ids']) ? (array)$block['post_ids'] : [];
            $new_pid = isset($block['new_player_id']) ? sanitize_text_field($block['new_player_id']) : '';
            if ($post_ids && $new_pid) {
                $new_shortcode = '[cpplayer id="' . esc_attr($new_pid) . '"]';
                $content_new = "<!-- wp:shortcode -->\n" . $new_shortcode . "\n<!-- /wp:shortcode -->";
                foreach ($post_ids as $post_id) {
                    $post = get_post($post_id);
                    if (!$post) continue;
                    $content = $post->post_content;
                    if ($content_new !== $content) {
                        wp_update_post(['ID'=>$post_id, 'post_content'=>$content_new]);
                        $block_report[] = 'В посте <a href="' . get_edit_post_link($post_id) . '" target="_blank">' . esc_html($post->post_title) . '</a> шорткоды заменены.';
                    } else {
                        $block_report[] = 'В посте <a href="' . get_edit_post_link($post_id) . '" target="_blank">' . esc_html($post->post_title) . '</a> изменений не было.';
                    }
                }
            } else {
                $block_report[] = '<span style="color:red;">Выберите записи и новый плеер для замены!</span>';
            }
            $report[] = $block_report;
        }
    }
    ?>
    <div class="wrap">
        <h1>Массовая замена шорткодов <span style="color:#F658A4;font-size:0.7em;vertical-align:middle;">БЕТА</span></h1>
        <form method="get" style="margin-bottom: 10px;display:flex;gap:10px;align-items:end;">
            <input type="hidden" name="page" value="cpplayer_bulk_shortcode_replace">
            <input type="text" name="s" value="<?= esc_attr($search_term) ?>" placeholder="Поиск по записям..." style="flex:1;min-width:180px;">
            <input type="submit" value="Поиск" class="button">
            <?php if (!empty($search_term)): ?>
                <a href="<?= esc_url(admin_url('admin.php?page=cpplayer_bulk_shortcode_replace')) ?>" class="button">Сбросить</a>
            <?php endif; ?>
        </form>
        <form method="post" style="max-width:700px;" id="cpplayer-bulk-replace-form">
            <div id="cpplayer-bulk-replace-blocks">
            </div>
            <button type="button" class="button" id="cpplayer-add-replace-block-btn" style="margin:10px 0 20px 0;font-size:1.2em;">➕ Добавить замену</button>
            <br>
            <button type="submit" name="bulk_replace" class="button button-primary">Заменить шорткоды</button>
        </form>
        <?php if ($report): ?>
            <div style="margin-top:18px;padding:12px 18px;background:#f7f7f7;border-radius:6px;">
                <b>Результат:</b><br>
                <?php foreach ($report as $i => $block_report): ?>
                    <div style="margin-bottom:10px;"><b>Блок #<?= $i+1 ?>:</b><br><?php foreach ($block_report as $msg) echo $msg . '<br>'; ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <p style="margin-top:24px;color:#888;">В каждом блоке можно выбрать свои записи и плеер для замены.<br>Это <b>бета-функция</b>, используйте с осторожностью!</p>
        <script>
        const cpplayerPosts = <?= json_encode(array_map(function($p){return ['id'=>$p->ID,'title'=>$p->post_title];}, $posts)) ?>;
        const cpplayerPlayers = <?= json_encode($players) ?>;
        let cpplayerReplaceBlockCount = 0;
        function createReplaceBlock(idx) {
            return `
            <div class="cpplayer-replace-block" style="border:1px solid #eee;background:#fafbfc;border-radius:8px;padding:16px 18px;margin-bottom:18px;position:relative;">
                <div style="position:absolute;top:10px;right:10px;">
                    <button type="button" class="button" onclick="this.closest('.cpplayer-replace-block').remove();cpplayerUpdateReplaceNumbers();">✖</button>
                </div>
                <div style="font-weight:bold;font-size:1.1em;margin-bottom:10px;">Блок замены #<span class="cpplayer-replace-block-num">
                    ${idx+1}
                </span></div>
                <div style="margin-bottom:10px;">
                    <label>Записи для замены:<br>
                        <select name="block[${idx}][post_ids][]" multiple size="6" style="width:100%;max-width:400px;">
                            ${cpplayerPosts.map(p=>`<option value="${p.id}">${p.title.replace(/"/g,'&quot;')} [ID:${p.id}]</option>`).join('')}
                        </select>
                        <div style="color:#888;font-size:0.95em;">Можно выбрать несколько записей</div>
                    </label>
                </div>
                <div style="margin-bottom:10px;">
                    <label>Новый плеер для шорткода:<br>
                        <select name="block[${idx}][new_player_id]" required style="width:100%;max-width:400px;">
                            <option value="">-- Выбрать из списка --</option>
                            ${Object.entries(cpplayerPlayers).map(([id,pl])=>`<option value="${id}">${pl.title.replace(/"/g,'&quot;')} [${id}]</option>`).join('')}
                        </select>
                    </label>
                </div>
            </div>`;
        }
        function cpplayerUpdateReplaceNumbers() {
            document.querySelectorAll('.cpplayer-replace-block').forEach((block,i)=>{
                block.querySelector('.cpplayer-replace-block-num').textContent = i+1;
                let sel = block.querySelector('select[name^="block["]');
                if(sel) sel.name = `block[${i}][post_ids][]`;
                let player = block.querySelector('select[name$="[new_player_id]"]');
                if(player) player.name = `block[${i}][new_player_id]`;
            });
        }
        function cpplayerInitBulkReplace() {
            const addBtn = document.getElementById('cpplayer-add-replace-block-btn');
            const blocksContainer = document.getElementById('cpplayer-bulk-replace-blocks');
            if (addBtn && blocksContainer) {
                let blockCounter = 0;
                function addNewBlock() {
                    const newBlockHTML = createReplaceBlock(blockCounter);
                    blocksContainer.insertAdjacentHTML('beforeend', newBlockHTML);
                    blockCounter++;
                    cpplayerUpdateReplaceNumbers();
                }
                addBtn.addEventListener('click', addNewBlock);
                if (!blocksContainer.querySelector('.cpplayer-replace-block')) {
                    addNewBlock(); // Гарантируем стартовый блок
                }
            }
            document.addEventListener('click', function(e) {
                if (e.target && e.target.closest && e.target.closest('.cpplayer-replace-block') && e.target.textContent.trim() === '✖') {
                    const blockToRemove = e.target.closest('.cpplayer-replace-block');
                    if (blockToRemove) {
                        blockToRemove.remove();
                        cpplayerUpdateReplaceNumbers();
                    }
                }
            });
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', cpplayerInitBulkReplace);
        } else {
            cpplayerInitBulkReplace();
        }
        </script>
    </div>
    <?php
}

function cpplayer_videos_page() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['cpplayer_save_video']) && check_admin_referer('cpplayer_video_nonce')) {
        $videos = get_option('cpplayer_videos', []);
        $video_id = isset($_POST['cpplayer_video_id']) && !empty($_POST['cpplayer_video_id']) ? sanitize_text_field($_POST['cpplayer_video_id']) : 'video_' . uniqid();
        
        $videos[$video_id] = [
            'name' => sanitize_text_field($_POST['cpplayer_video_name']),
            'url' => esc_url_raw($_POST['cpplayer_video_url']),
        ];
        
        update_option('cpplayer_videos', $videos);
        $message = isset($_POST['cpplayer_video_id']) && !empty($_POST['cpplayer_video_id']) ? 'Видеоролик обновлен.' : 'Видеоролик добавлен.';
        echo '<div class="updated"><p>' . $message . '</p></div>';
    }

    if (isset($_GET['delete_video']) && check_admin_referer('cpplayer_delete_video_nonce')) {
        $videos = get_option('cpplayer_videos', []);
        $video_id_to_delete = sanitize_text_field($_GET['delete_video']);
        if (isset($videos[$video_id_to_delete])) {
            unset($videos[$video_id_to_delete]);
            update_option('cpplayer_videos', $videos);
            echo '<div class="updated"><p>Видеоролик удален.</p></div>';
        }
    }
    
    $all_videos = get_option('cpplayer_videos', []);
    $edit_video_id = isset($_GET['edit_video']) ? sanitize_text_field($_GET['edit_video']) : null;
    $video_to_edit = ($edit_video_id && isset($all_videos[$edit_video_id])) ? $all_videos[$edit_video_id] : null;

    ?>
    <div class="wrap cpplayer-videos-wrap">
        <h1>Управление видеороликами</h1>
        <p class="description" style="margin-bottom: 1em;">
            Добавленные здесь видеоролики будут случайным образом проигрываться перед основным контентом во всех плеерах.
        </p>
        
        <form method="post" class="form-wrap">
            <h2><?= $video_to_edit ? 'Редактировать видеоролик' : 'Добавить новый видеоролик' ?></h2>
            <?php wp_nonce_field('cpplayer_video_nonce'); ?>
            <input type="hidden" name="cpplayer_video_id" value="<?= esc_attr($edit_video_id) ?>">
            
            <div class="form-field">
                <label for="cpplayer_video_name">Название</label>
                <input type="text" name="cpplayer_video_name" id="cpplayer_video_name" value="<?= esc_attr($video_to_edit['name'] ?? '') ?>" required>
                <p class="description">Название для вашей идентификации (напр. "Преролл 1").</p>
            </div>
            
            <div class="form-field">
                <label for="cpplayer_video_url">URL видеоролика</label>
                <input type="text" name="cpplayer_video_url" id="cpplayer_video_url" value="<?= esc_attr($video_to_edit['url'] ?? '') ?>" required class="regular-text">
                <button type="button" id="upload_video_button" class="button">Выбрать из библиотеки</button>
                <div id="video_preview_container">
                    <?php if ($video_to_edit && !empty($video_to_edit['url'])): ?>
                        <video src="<?= esc_url($video_to_edit['url']) ?>" controls></video>
                    <?php endif; ?>
                </div>
            </div>
            
            <p class="submit">
                <input type="submit" name="cpplayer_save_video" class="button button-primary" value="<?= $video_to_edit ? 'Обновить видеоролик' : 'Добавить видеоролик' ?>">
                <?php if ($video_to_edit): ?>
                    <a href="?page=cpplayer_videos" class="button">Отмена</a>
                <?php endif; ?>
            </p>
        </form>

        <h2>Существующие видеоролики</h2>
        <div class="cpplayer-cards">
            <?php if (empty($all_videos)): ?>
                <p>Видеоролики еще не добавлены.</p>
            <?php else: ?>
                <?php foreach ($all_videos as $id => $video): ?>
                <div class="cpplayer-card">
                    <div class="cpplayer-card-video-preview">
                        <video src="<?= esc_url($video['url']) ?>" controls preload="metadata"></video>
                    </div>
                    <div class="cpplayer-card-content">
                        <div class="cpplayer-card-title"><?= esc_html($video['name']) ?></div>
                        <div class="cpplayer-card-url"><code><?= esc_html($video['url']) ?></code></div>
                        <div class="cpplayer-card-actions">
                            <a href="?page=cpplayer_videos&edit_video=<?= esc_attr($id) ?>" class="button button-secondary">Редактировать</a>
                            <a href="<?= wp_nonce_url('?page=cpplayer_videos&delete_video=' . esc_attr($id), 'cpplayer_delete_video_nonce') ?>" onclick="return confirm('Вы уверены, что хотите удалить этот видеоролик?')" class="button delete-button">Удалить</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        var mediaUploader;

        $('#upload_video_button').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Выберите видеоролик',
                button: { text: 'Выбрать видео' },
                multiple: false,
                library: { type: 'video' }
            });

            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#cpplayer_video_url').val(attachment.url).trigger('change');
            });

            mediaUploader.open();
        });

        $('#cpplayer_video_url').on('input change', function() {
            var url = $(this).val();
            var previewContainer = $('#video_preview_container');
            previewContainer.empty();
            if (url && (url.endsWith('.mp4') || url.endsWith('.webm') || url.endsWith('.ogv'))) {
                previewContainer.html('<video src="' + url + '" controls></video>');
            }
        });
    });
    </script>
    <?php
}

add_action('wp_ajax_cpplayer_reset_stream_stats', function() {
    if (!current_user_can('manage_options')) wp_send_json_error(['error' => 'no_rights']);
    check_ajax_referer('cpplayer_nonce', 'nonce');
    $id = isset($_POST['id']) ? sanitize_text_field($_POST['id']) : '';
    if (!$id) wp_send_json_error(['error' => 'no_id']);
    $stats = get_option('cpplayer_stream_stats', []);
    if (isset($stats[$id])) {
        unset($stats[$id]);
        update_option('cpplayer_stream_stats', $stats);
    }
    wp_send_json_success();
});

add_action('wp_ajax_cpplayer_reset_cache', function() {
    if (!current_user_can('manage_options')) wp_send_json_error(['error' => 'no_rights']);
    check_ajax_referer('cpplayer_nonce', 'nonce');
    if (!current_user_can('manage_options')) wp_send_json_error(['error' => 'no_rights']);
    $ver = intval(get_option('cpplayer_cache_version', 1));
    $ver = max(1, $ver + 1);
    update_option('cpplayer_cache_version', $ver);
    wp_send_json_success(['ver' => $ver]);
});