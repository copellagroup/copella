window.CPPlayer = window.CPPlayer || {};

CPPlayer.bootstrap = function bootstrap() {
  document.addEventListener('DOMContentLoaded', function() {
    try {
      var isLegacy = false;
      if (!('classList' in document.documentElement)) isLegacy = true;
      if (!('requestAnimationFrame' in window)) isLegacy = true;
      var testDiv = document.createElement('div');
      testDiv.style.display = 'flex';
      if (testDiv.style.display !== 'flex') isLegacy = true;
      if (isLegacy) {
        document.querySelectorAll('.cpplayer-container').forEach(function(container){
          container.classList.add('cpplayer-legacy');
          var video = container.querySelector('video');
          if (video) video.controls = true;
        });
        return;
      }
    } catch (e) {}

    if (typeof CPPlayer.initPlayers === 'function') {
      CPPlayer.initPlayers();
    }
  });
};

CPPlayer.bootstrap();

