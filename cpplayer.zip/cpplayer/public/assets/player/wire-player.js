window.CPPlayer = window.CPPlayer || {};

CPPlayer.wirePlayer = function wirePlayer(container, media) {
  const playBtn = container.querySelector('.cpplayer-play');
  const progressContainer = container.querySelector('.cpplayer-progress');
  const progressPlayed = container.querySelector('.cpplayer-progress-played');
  const progressBuffer = container.querySelector('.cpplayer-progress-buffer');
  const time = container.querySelector('.cpplayer-time');
  const volumeContainer = container.querySelector('.cpplayer-volume-container');
  const volume = volumeContainer ? volumeContainer.querySelector('.cpplayer-volume') : null;
  const volumeBtn = volumeContainer ? volumeContainer.querySelector('.cpplayer-volume-btn') : null;
  const fullscreen = container.querySelector('.cpplayer-fullscreen');
  const controls = container.querySelector('.cpplayer-controls');
  const titleEl = container.querySelector('.cpplayer-title');
  const videoWrapper = container.querySelector('.cpplayer-video-wrapper');

  let centerBtn = container.querySelector('.cpplayer-center-btn');
  if (!centerBtn) {
    centerBtn = document.createElement('button');
    centerBtn.className = 'cpplayer-center-btn';
    centerBtn.innerHTML = `
      <svg viewBox="0 0 100 100" width="80" height="80" class="cpplayer-center-svg">
        <circle cx="50" cy="50" r="48" fill="transparent"/>
        <g class="cpplayer-center-icon-container">
          <polygon id="center-play-icon" class="cpplayer-center-icon" points="37.5,30 72.5,50 37.5,70" fill="#fff"/>
          <g id="center-pause-icon" class="cpplayer-center-icon">
            <rect x="31" y="28" width="14" height="44" rx="3" fill="#fff"/>
            <rect x="55" y="28" width="14" height="44" rx="3" fill="#fff"/>
          </g>
        </g>
      </svg>
      <div class="cpplayer-spinner"></div>`;
    centerBtn.style.display = '';
    centerBtn.type = 'button';
    centerBtn.title = 'Play/Pause';
    videoWrapper.appendChild(centerBtn);
  }

  let controlsVisible = true;
  let hideTimeout = null;
  let displayProgress = 0;
  let targetProgress = 0;
  let animationFrameRequest = null;
  let isSeeking = false;
  let wasPlayingBeforeSeek = false;

  const centerPlayIcon = centerBtn.querySelector('#center-play-icon');
  const centerPauseIcon = centerBtn.querySelector('#center-pause-icon');
  const spinnerEl = centerBtn.querySelector('.cpplayer-spinner');

  
  
  if (centerPlayIcon) {
    centerPlayIcon.style.opacity = '1';
    centerPlayIcon.style.transform = 'scale(1) rotate(0deg)';
  }
  if (centerPauseIcon) {
    centerPauseIcon.style.opacity = '0';
    centerPauseIcon.style.transform = 'scale(0.5) rotate(-30deg)';
  }
  if (playBtn) {
    playBtn.classList.remove('is-playing');
  }

  let loadingHideTimeout = null;
  const setLoading = (isLoading) => {
    if (isLoading) {
      if (loadingHideTimeout) { clearTimeout(loadingHideTimeout); loadingHideTimeout = null; }
      container.classList.add('is-loading');
      
      showControls();
    } else {
      if (loadingHideTimeout) clearTimeout(loadingHideTimeout);
      loadingHideTimeout = setTimeout(() => {
        container.classList.remove('is-loading');
      }, 100); 
    }
  };

  function updateCenterBtnVisibility() {
    
    if (controls) controls.style.display = '';
    centerBtn.style.display = controlsVisible ? '' : 'none';
  }

  const shouldKeepVisible = () => {
    const isLoading = container.classList.contains('is-loading');
    const tabVisible = document.visibilityState !== 'hidden';

    const isTouchDevice = (
      ('ontouchstart' in window) ||
      (navigator.maxTouchPoints && navigator.maxTouchPoints > 0) ||
      (window.matchMedia && window.matchMedia('(pointer: coarse)').matches)
    );

    // On touch devices, allow auto-hide even if paused (common when autoplay is blocked)
    if (isTouchDevice) {
      return isLoading || !tabVisible;
    }

    const isPaused = media.paused;
    return isLoading || isPaused || !tabVisible;
  };

  function scheduleHideIfNeeded() {
    if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; }
    if (shouldKeepVisible()) return;
    hideTimeout = setTimeout(() => {
      if (!shouldKeepVisible()) {
        container.classList.remove('cpplayer-active');
        controlsVisible = false;
        updateCenterBtnVisibility();
      }
      hideTimeout = null;
    }, 5000);
  }

  function showControls() {
    container.classList.add('cpplayer-active');
    controlsVisible = true;
    if (controls) controls.style.display = '';
    if (hideTimeout) clearTimeout(hideTimeout);
    updateCenterBtnVisibility();
    scheduleHideIfNeeded();
  }
  function hideControls() {
    container.classList.remove('cpplayer-active');
    controlsVisible = false;
    if (hideTimeout) clearTimeout(hideTimeout);
    hideTimeout = null;
    updateCenterBtnVisibility();
  }

  function togglePlay() {
    if (media.paused) media.play(); else media.pause();
  }

  centerBtn.addEventListener('click', togglePlay);
  playBtn.addEventListener('click', togglePlay);

  media.addEventListener('play', function() {
    playBtn.classList.add('is-playing');
    CPPlayer.state.requestWakeLock();
    centerPlayIcon.style.opacity = '0';
    centerPlayIcon.style.transform = 'scale(0.5) rotate(30deg)';
    centerPauseIcon.style.opacity = '1';
    centerPauseIcon.style.transform = 'scale(1) rotate(0deg)';
    updateCenterBtnVisibility();
    startAnimationLoop();
    setLoading(false);
    scheduleHideIfNeeded();
  });

  media.addEventListener('pause', function() {
    playBtn.classList.remove('is-playing');
    CPPlayer.state.releaseWakeLock();
    centerPlayIcon.style.opacity = '1';
    centerPlayIcon.style.transform = 'scale(1) rotate(0deg)';
    centerPauseIcon.style.opacity = '0';
    centerPauseIcon.style.transform = 'scale(0.5) rotate(-30deg)';
    container.classList.add('cpplayer-active');
    controlsVisible = true;
    updateCenterBtnVisibility();
    if (animationFrameRequest) {
      cancelAnimationFrame(animationFrameRequest);
      animationFrameRequest = null;
    }
    setLoading(false);
    if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; }
  });

  
  media.cpplayer = {
    playMainVideo: () => media.play(),
    notifyAdStarted: () => {
      container.classList.add('ad-playing');
      showControls();
    },
    notifyAdEnded: () => {
      container.classList.remove('ad-playing');
      showControls();
    }
  };

  function startAnimationLoop() {
    if (!animationFrameRequest && !media.paused) {
      animationFrameRequest = requestAnimationFrame(animateProgress);
    }
  }

  function animateProgress() {
    if (media.paused) { animationFrameRequest = null; return; }
    const dur = (typeof media.duration === 'number' && isFinite(media.duration) && media.duration > 0) ? media.duration : null;
    const cur = media.currentTime || 0;
    const currentPercent = dur ? (cur / dur) * 100 : 0;
    targetProgress = Math.max(0, Math.min(100, currentPercent));

    displayProgress += (targetProgress - displayProgress) * 0.06;
    progressPlayed.style.width = displayProgress + '%';
    animationFrameRequest = requestAnimationFrame(animateProgress);
  }

  container.addEventListener('mouseenter', showControls);
  container.addEventListener('mouseleave', hideControls);
  ;['mousemove','pointermove'].forEach(evt => container.addEventListener(evt, showControls));

  // Mobile tap-to-toggle for controls, avoiding conflicts with touchmove/controls taps
  let lastTap = 0;
  let touchMoved = false;
  container.addEventListener('touchstart', () => {
    touchMoved = false;
  }, { passive: true });
  container.addEventListener('touchmove', () => {
    touchMoved = true;
    showControls();
  }, { passive: true });
  container.addEventListener('touchend', (e) => {
    const now = Date.now();
    const delta = now - lastTap;
    lastTap = now;
    if (delta < 300) return; // ignore double-tap
    if (touchMoved) return; // ignore swipes/drags
    // Ignore taps on controls elements
    const tappedEl = e.target;
    if (controls && controls.contains(tappedEl)) return;
    if (volume && volume.contains && volume.contains(tappedEl)) return;
    if (volumeBtn && tappedEl === volumeBtn) return;
    if (fullscreen && tappedEl === fullscreen) return;
    if (playBtn && tappedEl === playBtn) return;
    if (centerBtn && centerBtn.contains && centerBtn.contains(tappedEl)) return;

    if (controlsVisible) {
      hideControls();
    } else {
      showControls();
    }
  }, { passive: true });

  media.addEventListener('timeupdate', function() {
    const currentTimeForDisplay = media.currentTime;
    const durationForDisplay = media.duration;
    time.textContent = CPPlayer.formatTime(currentTimeForDisplay) + ' / ' + CPPlayer.formatTime(durationForDisplay);
    
    if (!media.paused) setLoading(false);
  });

  
  ['loadstart','waiting','seeking','stalled','emptied'].forEach(evt => {
    media.addEventListener(evt, () => { setLoading(true); showControls(); });
  });
  ['canplay','canplaythrough','playing','loadeddata','seeked'].forEach(evt => {
    media.addEventListener(evt, () => { setLoading(false); showControls(); });
  });

  
  setLoading(true);

  
  try {
    if (media.readyState >= 2) {
      
      media.pause();
    } else {
      media.addEventListener('loadeddata', function onLd() {
        media.removeEventListener('loadeddata', onLd);
        try { media.pause(); } catch(e) {}
        showControls();
      }, { once: true });
    }
  } catch(e) {}

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      showControls();
    } else {
      if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; }
    }
  });
  window.addEventListener('focus', showControls);

  function updateBuffer() {
    if (media.buffered && media.buffered.length > 0 && media.duration > 0 && isFinite(media.duration)) {
      let currentBufferedEnd = 0;
      for (let i = 0; i < media.buffered.length; i++) {
        if (media.buffered.start(i) <= media.currentTime && media.currentTime < media.buffered.end(i)) {
          currentBufferedEnd = media.buffered.end(i);
          break;
        }
      }
      if (currentBufferedEnd === 0 && media.buffered.length > 0) {
        currentBufferedEnd = media.buffered.end(media.buffered.length - 1);
      }
      const displayBufferedPercent = (currentBufferedEnd / media.duration) * 100;
      progressBuffer.style.width = Math.min(100, Math.max(0, displayBufferedPercent)) + '%';
    }
  }
  media.addEventListener('progress', updateBuffer);

  
  if (progressContainer) {
    const seekToClientX = (clientX) => {
      if (!isFinite(media.duration) || media.duration <= 0) return;
      const rect = progressContainer.getBoundingClientRect();
      const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      const newTime = ratio * media.duration;
      try {
        wasPlayingBeforeSeek = !media.paused && !media.ended;
        isSeeking = true;
        media.currentTime = newTime;
        if (wasPlayingBeforeSeek) {
          media.play().catch(()=>{});
        }
      } finally {
        isSeeking = false;
      }
    };

    let isPointerDown = false;

    const onPointerDown = (e) => {
      isPointerDown = true;
      seekToClientX(e.clientX || (e.touches && e.touches[0] && e.touches[0].clientX) || 0);
      document.addEventListener('pointermove', onPointerMove);
      document.addEventListener('pointerup', onPointerUp, { once: true });
    };
    const onPointerMove = (e) => {
      if (!isPointerDown) return;
      seekToClientX(e.clientX);
    };
    const onPointerUp = () => {
      isPointerDown = false;
      document.removeEventListener('pointermove', onPointerMove);
    };

    
    if (window.PointerEvent) {
      progressContainer.addEventListener('pointerdown', onPointerDown);
    } else {
      progressContainer.addEventListener('mousedown', (e) => {
        onPointerDown(e);
        const onMouseMove = (ev) => onPointerMove(ev);
        const onMouseUp = () => {
          onPointerUp();
          document.removeEventListener('mousemove', onMouseMove);
          document.removeEventListener('mouseup', onMouseUp);
        };
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp, { once: true });
      });
      progressContainer.addEventListener('touchstart', (e) => {
        const touchX = e.touches && e.touches[0] ? e.touches[0].clientX : 0;
        seekToClientX(touchX);
      }, { passive: true });
      progressContainer.addEventListener('touchmove', (e) => {
        const touchX = e.touches && e.touches[0] ? e.touches[0].clientX : 0;
        seekToClientX(touchX);
      }, { passive: true });
    }
  }

  if (volume) {
    const updateVolumeFill = () => {
      const val = parseFloat(volume.value || '0');
      const percent = Math.max(0, Math.min(1, val)) * 100;
      volume.style.setProperty('--cpplayer-volume-fill', percent + '%');
    };
    const updateVolumeIcon = () => {
      if (!volumeBtn) return;
      if (media.muted || media.volume === 0) {
        volumeBtn.classList.add('is-muted');
      } else {
        volumeBtn.classList.remove('is-muted');
      }
    };
    updateVolumeFill();
    media.volume = volume ? parseFloat(volume.value) : 1;
    media.muted = volume ? parseFloat(volume.value) === 0 : false;
    updateVolumeIcon();

    volume.addEventListener('input', function() {
      media.volume = parseFloat(this.value);
      media.muted = parseFloat(this.value) === 0;
      updateVolumeFill();
      updateVolumeIcon();
    });

    media.addEventListener('volumechange', () => {
      if (volume && !isNaN(media.volume)) {
        volume.value = media.muted ? 0 : media.volume;
        updateVolumeFill();
      }
      updateVolumeIcon();
    });

    if (volumeBtn) {
      volumeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        volume.classList.toggle('is-visible');
      });
    }

    document.addEventListener('click', function(e) {
      if (volume && volume.classList.contains('is-visible') && !volume.contains(e.target) && e.target !== volumeBtn) {
        volume.classList.remove('is-visible');
      }
    });
  }

  if (fullscreen) {
    const wrapper = container.querySelector('.cpplayer-video-wrapper');
    const updateFullscreenClass = () => {
      const fsEl = document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement;
      const isFs = fsEl === wrapper || container.classList.contains('cpplayer-pseudo-fullscreen');
      if (isFs) container.classList.add('cpplayer-fullscreen'); else container.classList.remove('cpplayer-fullscreen');
      
      try {
        if (screen.orientation && typeof screen.orientation.lock === 'function') {
          if (isFs) {
            screen.orientation.lock('landscape').catch(()=>{});
          } else {
            screen.orientation.lock('portrait').catch(()=>{});
          }
        }
      } catch(e) {}
      if (isFs) { try { showControls(); } catch(e) {} }
    };
    fullscreen.addEventListener('click', function() {
      const isCurrentlyFs = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement) || container.classList.contains('cpplayer-pseudo-fullscreen');
      if (!isCurrentlyFs) {
        
        try {
          if (screen.orientation && typeof screen.orientation.lock === 'function') screen.orientation.lock('landscape').catch(()=>{});
        } catch(e) {}
        const reqFs = wrapper && (wrapper.requestFullscreen || wrapper.webkitRequestFullscreen || wrapper.mozRequestFullScreen || wrapper.msRequestFullscreen);
        if (reqFs) {
          reqFs.call(wrapper);
        } else {
          container.classList.add('cpplayer-pseudo-fullscreen');
          updateFullscreenClass();
        }
      } else {
        if (container.classList.contains('cpplayer-pseudo-fullscreen')) {
          container.classList.remove('cpplayer-pseudo-fullscreen');
          updateFullscreenClass();
        } else {
          const exitFs = document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen;
          if (exitFs) exitFs.call(document);
        }
      }
    });
    ['fullscreenchange','webkitfullscreenchange','mozfullscreenchange','MSFullscreenChange'].forEach(evt => {
      document.addEventListener(evt, updateFullscreenClass);
    });
  }
};
