window.CPPlayer = window.CPPlayer || {};

CPPlayer.formatTime = function formatTime(sec, showMilliseconds = false) {
  if (isNaN(sec)) return '00:00';
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const ms = Math.floor((sec - Math.floor(sec)) * 1000);

  let timeStr = '';
  if (h > 0) {
    timeStr = (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  } else {
    timeStr = (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
  }

  if (showMilliseconds) {
    timeStr += '.' + ('000' + ms).slice(-3);
  }

  return timeStr;
};

