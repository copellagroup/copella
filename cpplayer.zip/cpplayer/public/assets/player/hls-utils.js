window.CPPlayer = window.CPPlayer || {};

CPPlayer.hls = {
  getMimeType: function getMimeType(src) {
    if (!src) return '';
    if (src.endsWith('.m3u8')) return 'application/vnd.apple.mpegurl';
    if (src.endsWith('.mp4')) return 'video/mp4';
    if (src.endsWith('.webm')) return 'video/webm';
    if (src.endsWith('.ogv')) return 'video/ogg';
    if (src.endsWith('.ts')) return 'video/mp2t';
    return '';
  },

  reinitHls: function reinitHls(container, media, hlsSrc, onFatal) {
    if (container.hlsInstance) {
      container.hlsInstance.destroy();
    }
    if (window.Hls && Hls.isSupported()) {
      let mediaErrorCount = 0;
      const hlsConfig = {
        fragLoadingMaxRetry: 6,
        fragLoadingRetryDelay: 1000,
        levelLoadingMaxRetry: 4,
        levelLoadingRetryDelay: 1000,
      };
      const hls = new Hls(hlsConfig);
      container.hlsInstance = hls;

      const hlsErrorHandler = (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              if (typeof onFatal === 'function') onFatal();
              hls.destroy();
              break;
          }
        } else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
          mediaErrorCount++;
          if (mediaErrorCount > 5) {
            mediaErrorCount = 0;
            hls.destroy();
            setTimeout(() => {
              CPPlayer.hls.reinitHls(container, media, hlsSrc, onFatal);
            }, 2000);
          }
        }
      };

      hls.loadSource(hlsSrc);
      hls.attachMedia(media);
      hls.on(Hls.Events.ERROR, hlsErrorHandler);
      hls.on(Hls.Events.MANIFEST_PARSED, function () {
        if (typeof window.checkHlsAudioTracks === 'function') {
          window.checkHlsAudioTracks(hls);
        }
      });
    } else if (media.canPlayType('application/vnd.apple.mpegurl')) {
      media.src = hlsSrc;
    }
  }
};

