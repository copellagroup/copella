window.CPPlayer = window.CPPlayer || {};

CPPlayer.dom = {
  create: function create(tag, className, html) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (html !== undefined) el.innerHTML = html;
    return el;
  },
  qs: function qs(root, sel) {
    return root.querySelector(sel);
  },
  qsa: function qsa(root, sel) {
    return Array.from(root.querySelectorAll(sel));
  }
};

