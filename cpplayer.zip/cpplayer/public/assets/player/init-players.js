window.CPPlayer = window.CPPlayer || {};

CPPlayer.initPlayers = function initPlayers() {
  document.querySelectorAll('.cpplayer-container').forEach(function(container) {
    if (container.dataset.initialized === 'true') return;
    const playerType = container.dataset.type;
    if (playerType !== 'video' && playerType !== 'stream') return;
    container.dataset.initialized = 'true';

    const isAudio = container.classList.contains('cpplayer-audio');
    const media = isAudio ? container.querySelector('.cpplayer-audio-el') : container.querySelector('.cpplayer-video');
    let src = media.getAttribute('src') || media.querySelector('source')?.getAttribute('src');
    container.dataset.originalSrc = container.dataset.shareSrc || src;

    if (src) {
      const mime = CPPlayer.hls.getMimeType(src);
      if (src.includes('.m3u8') || src.includes('.ts')) {
        
        CPPlayer.hls.reinitHls(container, media, src, () => {});
      } else if (mime && media.canPlayType(mime)) {
        media.src = src;
      } else {
        media.src = src;
      }
    }

    if (typeof CPPlayer.wirePlayer === 'function') {
      CPPlayer.wirePlayer(container, media);
    }

    
    if (playerType === 'video' && media && !media.__cpplayer_next_attached) {
      media.__cpplayer_next_attached = true;

      const getAjaxUrl = () => {
        try {
          if (window.cpplayer_ajax && (cpplayer_ajax.ajax_url || cpplayer_ajax.url)) {
            return cpplayer_ajax.ajax_url || cpplayer_ajax.url;
          }
        } catch (e) {}
        return '/wp-admin/admin-ajax.php';
      };

      const requestNextVideo = () => {
        const ajaxUrl = getAjaxUrl();
        const formData = new URLSearchParams();
        formData.set('action', 'cpplayer_get_next_video');
        
        
        
        

        return fetch(ajaxUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: formData.toString()
        })
          .then(res => {
            if (!res.ok) throw new Error('HTTP ' + res.status);
            return res.json();
          });
      };

      const onEnded = () => {
        
        if (container.classList.contains('ad-playing')) return;

        requestNextVideo()
          .then(data => {
            if (data && data.success && data.data && data.data.src) {
              const next = data.data;
              CPPlayer.showNextVideoOverlay(container, next, {
                seconds: 5
              });
            }
          })
          .catch(() => {});
      };

      media.addEventListener('ended', onEnded);
    }
  });
};



CPPlayer.updatePage = function updatePage(url, title) {
  try {
    if (url && typeof history.pushState === 'function') {
      history.pushState({}, title || document.title, url);
    }
    if (title) {
      document.title = title;
    }
  } catch(e) {
    
  }
};

CPPlayer.changeVideo = function changeVideo(containerOrSelector, options) {
  const opts = options || {};
  const src = opts.src;
  const title = opts.title;
  const pageUrl = opts.url;
  if (!src) return Promise.reject(new Error('CPPlayer.changeVideo: missing src'));

  const container = typeof containerOrSelector === 'string'
    ? document.querySelector(containerOrSelector)
    : containerOrSelector;
  if (!container) return Promise.reject(new Error('CPPlayer.changeVideo: container not found'));

  const isAudio = container.classList.contains('cpplayer-audio');
  const media = isAudio ? container.querySelector('.cpplayer-audio-el') : container.querySelector('.cpplayer-video');
  if (!media) return Promise.reject(new Error('CPPlayer.changeVideo: media element not found'));

  try {
    const titleEl = container.querySelector('.cpplayer-title');
    if (titleEl && title) { titleEl.textContent = title; }
  } catch(e) {}

  if (window.CPPlayer && CPPlayer.topLoader && typeof CPPlayer.topLoader.start === 'function') {
    CPPlayer.topLoader.start();
  }

  
  try { container.classList.add('cpplayer-active'); } catch(e) {}

  CPPlayer.updatePage(pageUrl, title);

  return new Promise(function(resolve) {
    try { media.pause && media.pause(); } catch(e) {}

    const mime = CPPlayer.hls.getMimeType(src);
    const isHls = src.includes('.m3u8') || src.includes('.ts');

    const onReady = () => {
      media.removeEventListener('loadeddata', onReady);
      media.removeEventListener('canplay', onReady);
      if (CPPlayer.topLoader && typeof CPPlayer.topLoader.done === 'function') {
        CPPlayer.topLoader.done();
      }
    // Делаем панель видимой и сбрасываем прогресс в начало при старте нового видео
    try { container.classList.add('cpplayer-active'); } catch(e) {}
    try { const pb = container.querySelector('.cpplayer-progress-played'); if (pb) pb.style.width = '0%'; } catch(e) {}
      try { container.classList.add('cpplayer-active'); } catch(e) {}
      const p = media.play && media.play();
      if (p && typeof p.catch === 'function') { p.catch(()=>{}); }
      resolve();
    };

    media.addEventListener('loadeddata', onReady, { once: true });
    media.addEventListener('canplay', onReady, { once: true });

    if (isHls) {
      CPPlayer.hls.reinitHls(container, media, src, function(){
        if (CPPlayer.topLoader && typeof CPPlayer.topLoader.done === 'function') {
          CPPlayer.topLoader.done();
        }
        resolve();
      });
    } else {
      if (mime && media.canPlayType(mime)) {
        media.src = src;
      } else {
        media.src = src;
      }
      try { media.load(); } catch(e) {}
    }
  });
};



CPPlayer.showNextVideoOverlay = function showNextVideoOverlay(containerOrSelector, nextData, opts) {
  const options = opts || {};
  const countdownSeconds = Math.max(1, parseInt(options.seconds, 10) || 5);

  const container = typeof containerOrSelector === 'string'
    ? document.querySelector(containerOrSelector)
    : containerOrSelector;
  if (!container || !nextData || !nextData.src) return;

  const wrapper = container.querySelector('.cpplayer-video-wrapper') || container;
  let overlay = wrapper.querySelector('.cpplayer-next-video-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'cpplayer-next-video-overlay';
    wrapper.appendChild(overlay);
  }

  
  overlay.innerHTML = '';
  const content = document.createElement('div');
  content.className = 'cpplayer-next-video-content';

  const info = document.createElement('div');
  info.className = 'cpplayer-next-video-info';
  const subtitle = document.createElement('div');
  subtitle.className = 'cpplayer-next-video-subtitle';
  subtitle.textContent = 'Следующее видео';
  const title = document.createElement('div');
  title.className = 'cpplayer-next-video-title';
  title.textContent = nextData.title || '';
  const countdown = document.createElement('div');
  countdown.className = 'cpplayer-next-video-countdown';
  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'cpplayer-next-video-cancel';
  cancelBtn.type = 'button';
  cancelBtn.textContent = 'Отмена';

  info.appendChild(subtitle);
  info.appendChild(title);
  info.appendChild(countdown);
  info.appendChild(cancelBtn);

  const thumb = document.createElement('div');
  thumb.className = 'cpplayer-next-video-thumb';
  const img = document.createElement('img');
  img.alt = nextData.title || '';
  if (nextData.thumbnail) img.src = nextData.thumbnail;
  thumb.appendChild(img);

  content.appendChild(info);
  content.appendChild(thumb);
  overlay.appendChild(content);

  
  overlay.classList.add('is-visible');

  let remaining = countdownSeconds;
  let timerId = null;

  const updateCountdown = () => {
    countdown.textContent = `Начнется через ${remaining} с`;
  };

  const cleanup = () => {
    if (timerId) { clearInterval(timerId); timerId = null; }
    overlay.classList.remove('is-visible');
    
    setTimeout(() => { if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay); }, 300);
  };

  const commitSwitch = () => {
    cleanup();
    CPPlayer.changeVideo(container, {
      src: nextData.src,
      title: nextData.title,
      url: nextData.url
    }).then(() => {
      
      try { CPPlayer.updateTitleAndLink(nextData.title, nextData.url); } catch (e) {}
      if (typeof window.reinitVideoRolls === 'function') {
        try { window.reinitVideoRolls(container); } catch (e) {}
      }
    });
  };

  
  cancelBtn.addEventListener('click', () => {
    cleanup();
  }, { once: true });
  
  overlay.addEventListener('click', () => {
    commitSwitch();
  }, { once: true });

  
  updateCountdown();
  timerId = setInterval(() => {
    remaining -= 1;
    if (remaining <= 0) {
      clearInterval(timerId); timerId = null;
      commitSwitch();
    } else {
      updateCountdown();
    }
  }, 1000);
};


CPPlayer.updateTitleAndLink = function updateTitleAndLink(title, url) {
  try {
    const selectors = [
      'h1.wp-block-post-title > a',
      'h1.entry-title > a',
      'h1.wp-block-post-title',
      'h1.entry-title'
    ];
    let el = null;
    for (const sel of selectors) {
      el = document.querySelector(sel);
      if (el) break;
    }
    if (!el) return;

    if (el.tagName && el.tagName.toLowerCase() === 'a') {
      el.textContent = title || document.title;
      if (url) el.href = url;
    } else {
      el.textContent = title || document.title;
      const linkInside = el.querySelector('a');
      if (linkInside && url) {
        linkInside.href = url;
        linkInside.textContent = title || linkInside.textContent;
      }
    }
  } catch (e) {}
};
