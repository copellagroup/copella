document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.cpplayer-container[data-type="stream"]').forEach(function(container) {
    const video = container.querySelector('.cpplayer-video');
    const videoWrapper = container.querySelector('.cpplayer-video-wrapper'); 
    const stub = container.querySelector('.cpplayer-stream-stub');
    const stubVideo = stub ? stub.querySelector('video') : null;
    const stubVolumeBtn = stub ? stub.querySelector('.cpplayer-stub-volume-btn') : null;
    const src = video.getAttribute('data-src');
    let hls;
    let noSegmentsTries = 0;
    let noSegmentsTimeout = null;
    const MAX_NOSEGMENT_TRIES = 5;
    const NOSEGMENT_RETRY_DELAY = 2000; 

    let latencyDiv = container.querySelector('.cpplayer-latency-indicator'); 
    if (!latencyDiv && videoWrapper) { 
        latencyDiv = document.createElement('div');
        latencyDiv.className = 'cpplayer-latency-indicator';
        latencyDiv.style.cssText = 'position:absolute;right:20px;bottom:16px;z-index:21;color:#fff;background:rgba(0,0,0,0.25);font-size:0.95em;padding:2px 12px;border-radius:12px;pointer-events:none;opacity:0.7;';
        videoWrapper.appendChild(latencyDiv);
    }
    if (latencyDiv) latencyDiv.textContent = ''; 
    

    let reconnectTries = 0;
    const MAX_RECONNECT_TRIES = 1000; 
    const RECONNECT_DELAY = 4000;
    let reconnectTimeout = null;

    const playerId = container.querySelector('.cpplayer-video').id || src;
    const heartBtn = container.querySelector('.cpplayer-heart-btn');
    const heartCountSpan = container.querySelector('.cpplayer-heart-count');
    const LS_KEY = 'cpplayer_stream_stats_' + playerId;
    let stats = { views: 0, likes: 0, liked: false };
    let statsLoaded = false;
    let likeInProgress = false;
    try {
      stats = JSON.parse(localStorage.getItem(LS_KEY)) || stats;
    } catch(e) {}
    
    function setSkeleton(on) {
      if (heartCountSpan) heartCountSpan.setAttribute('data-skeleton', on ? 'true' : 'false');
      if (!on && heartCountSpan) heartCountSpan.removeAttribute('data-skeleton');
    }
    if (heartCountSpan) setSkeleton(true);
    
    function sendStatToServer(action) {
      return fetch((window.cpplayer_ajax && window.cpplayer_ajax.url) || '/wp-admin/admin-ajax.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=cpplayer_stream_stat&id=${encodeURIComponent(playerId)}&stat_action=${action}`
      })
      .then(r => {
        if (!r.ok) throw new Error(`Network response was not ok: ${r.statusText}`);
        return r.json();
      })
      .then(data => {
        if (!data.success) throw new Error( (data.data && data.data.message) || 'API returned success:false');
        
        if (data.data) {
          stats.likes = data.data.likes !== undefined ? data.data.likes : stats.likes;
          localStorage.setItem(LS_KEY, JSON.stringify(stats));
          statsLoaded = true;
          updateStatsUI();
        }
        return data.data;
      });
    }
    
    if (heartBtn) {
        sendStatToServer('get').catch(err => {
          console.error("Failed to get initial stats:", err);
          statsLoaded = true;
          updateStatsUI();
        });
    } else {
        if (heartCountSpan) setSkeleton(false);
    }
    
    function updateStatsUI() {
      if (!heartBtn || !heartCountSpan) return;
      heartCountSpan.textContent = stats.likes;
      if (stats.liked) {
        heartBtn.classList.add('is-liked');
        
        const svg = heartBtn.querySelector('svg .cpplayer-heart-shape');
        if (svg) {
            svg.style.fill = '#F658A4';
            
        }
      } else {
        heartBtn.classList.remove('is-liked');
        const svg = heartBtn.querySelector('svg .cpplayer-heart-shape');
         if (svg) {
            svg.style.fill = 'none';
            
        }
      }
      if (statsLoaded && heartCountSpan) setSkeleton(false);
      heartBtn.title = stats.liked ? 'Убрать лайк' : 'Поставить лайк';
    }
    if (heartBtn) updateStatsUI();
    
    if (heartBtn) {
        heartBtn.addEventListener('click', function() {
          if (likeInProgress) return;
          likeInProgress = true;
          heartBtn.disabled = true;

          const action = !stats.liked ? 'like' : 'unlike';
          const originalStats = { ...stats };
          
          stats.liked = !originalStats.liked;
          stats.likes += stats.liked ? 1 : -1;
          updateStatsUI();

          sendStatToServer(action)
            .catch((err) => {
              console.error("Like/Unlike action failed:", err);
              stats.liked = originalStats.liked;
              stats.likes = originalStats.likes;
              updateStatsUI();
            })
            .finally(() => {
              likeInProgress = false;
              heartBtn.disabled = false;
              localStorage.setItem(LS_KEY, JSON.stringify(stats));
            });
        });
        heartBtn.addEventListener('mouseenter', function() { 
          heartBtn.title = stats.liked ? 'Убрать лайк' : 'Поставить лайк';
        });
    }

    
    let liveIndicator = container.querySelector('.cpplayer-live-indicator');
    let liveDot;
    const LIVE_EDGE_THRESHOLD = 5; 

    if (videoWrapper && !liveIndicator) { 
        liveIndicator = document.createElement('div');
        liveIndicator.className = 'cpplayer-live-indicator';
        
        liveDot = document.createElement('span');
        liveDot.className = 'cpplayer-live-indicator-dot';
        liveIndicator.appendChild(liveDot);

        const liveText = document.createTextNode('LIVE');
        liveIndicator.appendChild(liveText);

        videoWrapper.appendChild(liveIndicator);
    } else if (liveIndicator) { 
        liveDot = liveIndicator.querySelector('.cpplayer-live-indicator-dot');
        if (!liveDot) {
            liveDot = document.createElement('span');
            liveDot.className = 'cpplayer-live-indicator-dot';
            liveIndicator.insertBefore(liveDot, liveIndicator.firstChild); 
        }
    }
    
    function updateLiveIndicator() {
        if (!liveIndicator || !liveDot) {
            if (liveIndicator) liveIndicator.classList.remove('is-visible', 'is-at-live-edge');
            if (container) container.classList.remove('cpplayer-live-active');
            return;
        }

        let shouldBeVisible = false;

        if (hls && hls.media) {
            if (hls.liveSyncPosition !== null) {
                shouldBeVisible = true;
            }
        } else if (!window.Hls.isSupported() && video.src && video.duration === Infinity) {
            shouldBeVisible = true;
        }

        if (shouldBeVisible) {
            liveIndicator.classList.add('is-visible');
            container.classList.add('cpplayer-live-active');

            let liveEdgePosition;
            if (hls && hls.media && hls.liveSyncPosition !== null && typeof hls.liveSyncPosition !== 'undefined') {
                liveEdgePosition = hls.liveSyncPosition;
            } else {
                liveEdgePosition = video.seekable.length ? video.seekable.end(video.seekable.length - 1) : video.duration;
            }
            const currentTime = video.currentTime;

            if (typeof liveEdgePosition === 'number' && isFinite(liveEdgePosition)) {
                const isAtLiveEdge = Math.abs(currentTime - liveEdgePosition) < LIVE_EDGE_THRESHOLD;
                if (isAtLiveEdge) {
                    liveIndicator.classList.add('is-at-live-edge');
                } else {
                    liveIndicator.classList.remove('is-at-live-edge');
                }
            } else {
                liveIndicator.classList.remove('is-at-live-edge');
            }
        } else {
            liveIndicator.classList.remove('is-visible');
            liveIndicator.classList.remove('is-at-live-edge');
            container.classList.remove('cpplayer-live-active');
        }
    }

    if (liveIndicator) {
        liveIndicator.addEventListener('click', function() {

            let targetPosition;

            if (hls && hls.media && hls.liveSyncPosition !== null && typeof hls.liveSyncPosition !== 'undefined') {
                targetPosition = hls.liveSyncPosition;
            } else if (video.seekable && video.seekable.length > 0) {
                targetPosition = video.seekable.end(video.seekable.length - 1);
            } else {
                console.warn("Cannot determine a reliable live edge position to seek to.");
                return;
            }

            if (typeof targetPosition === 'number' && isFinite(targetPosition)) {
                 video.currentTime = targetPosition;
                 video.play().catch(err => console.warn("Error attempting to play after seeking to live:", err));
            } else {
                console.warn("Calculated targetPosition for live edge is not a finite number:", targetPosition);
            }
        });
    }
    
    function showStub(msg) {
      console.warn('Stream Player Stub:', msg);
      if (stub) {
        stub.style.display = 'flex';
        const playerTitle = container.querySelector('.cpplayer-title');
        if (playerTitle) {
            playerTitle.style.display = 'none';
        }
      }
      if (liveIndicator) liveIndicator.classList.remove('is-visible');
      container.classList.remove('cpplayer-live-active');
    }
    function hideStub() {
      if (stub) {
        stub.style.display = 'none';
        const playerTitle = container.querySelector('.cpplayer-title');
        if (playerTitle) {
            playerTitle.style.display = ''; 
        }
      }
      updateLiveIndicator();
      reconnectTries = 0; 
    }

    function tryReloadLevel() {
      if (hls && typeof hls.startLoad === 'function') {
        hls.startLoad(-1); 
      }
    }

    function scheduleReconnect() {
      if (reconnectTries < MAX_RECONNECT_TRIES) {
        if (reconnectTimeout) clearTimeout(reconnectTimeout);
        reconnectTimeout = setTimeout(() => {
          reconnectTries++;
          if (hls) {
            hls.destroy();
            hls = null; 
          }
          startHls();
        }, RECONNECT_DELAY);
      }
    }

    function updateLatency(details) {
      if (!latencyDiv) return; 
      
      if (!details || !details.fragments || details.fragments.length === 0) {
        latencyDiv.textContent = '';
        return;
      }
      
      const lastFrag = details.fragments[details.fragments.length - 1];
      
      const fragPDT = lastFrag.programDateTime;
      const fragDuration = lastFrag.duration;

      if (fragPDT && fragDuration) {
        const fragEnd = fragPDT / 1000 + fragDuration; 
        const now = Date.now() / 1000;
        const latency = Math.max(0, Math.round(now - fragEnd));
        latencyDiv.textContent = `Задержка: ${latency} сек`;
      } else {
        latencyDiv.textContent = ''; 
      }
    }

    function startHls() {
      if (video.cpplayer_hls) {
        video.cpplayer_hls.destroy();
      }
      hls = new window.Hls({
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
        enableWorker: true,
        lowLatencyMode: true,
        
        liveSyncDurationCount: 3, 
      });
      video.cpplayer_hls = hls;
      console.log('HLS: создан новый экземпляр Hls');
      hls.attachMedia(video);
      hls.on(window.Hls.Events.MEDIA_ATTACHED, function () {
        console.log('HLS: MEDIA_ATTACHED');
        hls.loadSource(src);
      });
      hls.on(window.Hls.Events.MANIFEST_PARSED, function (event, data) {
        console.log('HLS: MANIFEST_PARSED event', data);
        hideStub();
        video.play().catch(()=>{});
        reconnectTries = 0;
        updateLiveIndicator(); 
        if (hls.audioTracks) {
          if (hls.audioTracks.length > 0) {
            hls.audioTrack = 0;
          } else {
            console.warn('HLS: В потоке нет аудиодорожки!');
          }
        } else {
          console.warn('HLS: audioTracks не определены');
        }
      });
      hls.on(window.Hls.Events.ERROR, function (event, data) {
        console.error('HLS.js ERROR:', data);
        if (data.fatal) {
          const errorType = data.type;
          const errorDetails = data.details;
          console.warn(`HLS Error: type: ${errorType}, details: ${errorDetails}`);
          
          
          if (errorType === Hls.ErrorTypes.NETWORK_ERROR && 
              (errorDetails === Hls.ErrorDetails.MANIFEST_LOAD_ERROR || 
               errorDetails === Hls.ErrorDetails.MANIFEST_PARSING_ERROR ||
               errorDetails === Hls.ErrorDetails.LEVEL_LOAD_ERROR)) {
            showStub('Эфир временно недоступен');
            scheduleReconnect();
          } else if (errorType === Hls.ErrorTypes.MEDIA_ERROR && 
                     (errorDetails === Hls.ErrorDetails.BUFFER_APPEND_ERROR || 
                      errorDetails === Hls.ErrorDetails.BUFFER_STALLED_ERROR)) {
            
            
            
            console.warn("HLS Media Error, attempting recovery or scheduling reconnect.");
            showStub('Ошибка воспроизведения');
            scheduleReconnect();
          } else {
            showStub('Эфир недоступен'); 
            scheduleReconnect();
          }
        }
      });
      hls.on(window.Hls.Events.LEVEL_LOADED, function (event, data) {
        if (data.details && data.details.fragments && data.details.fragments.length > 0 && data.details.live) { 
          hideStub();
          noSegmentsTries = 0;
          if (noSegmentsTimeout) { clearTimeout(noSegmentsTimeout); noSegmentsTimeout = null; }
          updateLatency(data.details);
          updateLiveIndicator();
        } else if (data.details && !data.details.live) { 
            hideStub();
            if (liveIndicator) {
                liveIndicator.classList.remove('is-visible');
                liveIndicator.classList.remove('is-at-live-edge');
            }
            container.classList.remove('cpplayer-live-active');
        }
        else { 
          noSegmentsTries++;
          if (noSegmentsTries < MAX_NOSEGMENT_TRIES) {
            if (noSegmentsTimeout) clearTimeout(noSegmentsTimeout);
            noSegmentsTimeout = setTimeout(() => {
              tryReloadLevel();
            }, NOSEGMENT_RETRY_DELAY);
          } else {
            showStub('Эфир недоступен (нет сегментов)');
            scheduleReconnect();
          }
        }
      });
       hls.on(window.Hls.Events.FRAG_CHANGED, function (event, data) {
        if (data && data.frag) { 
          updateLatency({ fragments: [data.frag] }); 
          updateLiveIndicator();
        }
      });
      
      video.addEventListener('timeupdate', updateLiveIndicator);
      video.addEventListener('seeked', updateLiveIndicator);
      video.addEventListener('playing', updateLiveIndicator); 
    }

    video.addEventListener('cpplayer:hls_reinit', function() {
        if (window.Hls && window.Hls.isSupported()) {
            console.log("CP Player: Re-initializing HLS player.");
            startHls();
        }
    });

    const canPlayHlsNatively = video.canPlayType('application/vnd.apple.mpegurl') || video.canPlayType('application/x-mpegURL');
    if (window.Hls && window.Hls.isSupported()) {
      startHls();
    } else if (canPlayHlsNatively) {
      const source = document.createElement('source');
      source.setAttribute('src', src);
      source.setAttribute('type', 'application/vnd.apple.mpegurl');
      video.appendChild(source);
      
      video.addEventListener('loadedmetadata', function() {
        hideStub();
        video.play().catch(()=>{});
        
        
        
        if (liveIndicator && video.duration === Infinity) {
            liveIndicator.classList.add('is-visible');
            container.classList.add('cpplayer-live-active');
            
            
            
        }
      });
      video.addEventListener('error', function() {
        showStub('Эфир недоступен');
        
      });
    } else {
      showStub('Ваш браузер не поддерживает HLS');
    }

    video.addEventListener('error', function(e) {
      showStub('Ошибка видео: ' + (e.target.error ? e.target.error.message : 'неизвестная ошибка'));
    });
    video.addEventListener('stalled', function() {
      
      
      
    });
    video.addEventListener('emptied', function() {
      showStub('Видеоданные отсутствуют');
    });

    document.addEventListener('fullscreenchange', function() {
      const isFullscreen = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement || document.msFullscreenElement);
    });

    if (stubVideo && stubVolumeBtn) {
        stubVolumeBtn.addEventListener('click', function() {
            stubVideo.muted = !stubVideo.muted;
            updateStubVolumeIcon();
        });

        function updateStubVolumeIcon() {
            const iconSvg = stubVolumeBtn.querySelector('svg');
            if (!iconSvg) return;

            if (stubVideo.muted) {
                iconSvg.innerHTML = `
                    <path d="M11 5L6 9H2V15H6L11 19V5Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <line x1="15" y1="9" x2="21" y2="15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <line x1="21" y1="9" x2="15" y2="15" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                `;
                stubVolumeBtn.title = "Включить звук";
            } else {
                iconSvg.innerHTML = `
                    <path d="M11 5L6 9H2V15H6L11 19V5Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M15.54 8.46C17.4766 10.3967 17.4766 13.6033 15.54 15.54" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                `;
                stubVolumeBtn.title = "Выключить звук";
            }
        }
        updateStubVolumeIcon();
    }
  });
});