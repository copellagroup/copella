document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.cpplayer-container.cpplayer-audio').forEach(function(container) {
        const audio = container.querySelector('.cpplayer-audio-el');
        const playBtn = container.querySelector('.cpplayer-play');
        const progressContainer = container.querySelector('.cpplayer-audio-progress-container');
        const progressPlayed = container.querySelector('.cpplayer-audio-progress');
        const progressBuffer = container.querySelector('.cpplayer-audio-buffer');
        const time = container.querySelector('.cpplayer-audio-time');
        const volume = container.querySelector('.cpplayer-volume');
        const volumeBtn = container.querySelector('.cpplayer-volume-btn');
        let currentVolume = 1; 

        function formatTime(sec) {
            if (isNaN(sec)) return '00:00';
            const h = Math.floor(sec / 3600);
            const m = Math.floor((sec % 3600) / 60);
            const s = Math.floor(sec % 60);
            if (h > 0) {
                return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
            } else {
                return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
            }
        }

        playBtn.addEventListener('click', function() {
            if (audio.paused) {
                audio.play();
            } else {
                audio.pause();
            }
        });
        audio.addEventListener('play', function() {
            playBtn.classList.add('is-playing');
        });
        audio.addEventListener('pause', function() {
            playBtn.classList.remove('is-playing');
        });
        audio.addEventListener('timeupdate', function() {
            const percent = (audio.currentTime / audio.duration) * 100 || 0;
            progressPlayed.style.width = percent + '%';
            time.textContent = formatTime(audio.currentTime) + ' / ' + formatTime(audio.duration);
        });
        audio.addEventListener('loadedmetadata', function() {
            time.textContent = formatTime(0) + ' / ' + formatTime(audio.duration);
            progressPlayed.style.width = '0%';
            progressBuffer.style.width = '0%';
        });
        progressContainer.addEventListener('click', function(e) {
            const rect = progressContainer.getBoundingClientRect();
            const offsetX = e.clientX - rect.left;
            const percent = Math.max(0, Math.min(1, offsetX / rect.width));
            audio.currentTime = percent * audio.duration;
        });
        function updateBuffer() {
            let bufferedEnd = 0;
            if (audio.buffered && audio.buffered.length > 0 && audio.duration > 0) {
                for (let i = audio.buffered.length - 1; i >= 0; i--) {
                    if (audio.buffered.start(i) <= audio.currentTime) {
                        bufferedEnd = audio.buffered.end(i);
                        break;
                    }
                }
                if (bufferedEnd === 0 && audio.buffered.length > 0) {
                    bufferedEnd = audio.buffered.end(0);
                }
                if (bufferedEnd < audio.currentTime && audio.buffered.length > 0) {
                    bufferedEnd = audio.buffered.end(audio.buffered.length - 1);
                }
            }
            const bufferedPercent = (bufferedEnd / audio.duration) * 100 || 0;
            progressBuffer.style.width = Math.min(100, bufferedPercent) + '%';
        }
        audio.addEventListener('progress', updateBuffer);

        if (volume) {
            const updateVolumeFill = () => {
                const val = parseFloat(volume.value || '0');
                const percent = Math.max(0, Math.min(1, val)) * 100;
                volume.style.setProperty('--cpplayer-volume-fill', percent + '%');
            };
            updateVolumeFill();
            volume.addEventListener('input', function() {
                audio.volume = parseFloat(this.value);
                audio.muted = parseFloat(this.value) === 0;
                updateVolumeFill();
            });
        }

        if (volumeBtn && volume) {
            volumeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                volume.classList.toggle('is-visible');
            });
        }

        document.addEventListener('click', function(e) {
            if (volume && volume.classList.contains('is-visible') && !volume.contains(e.target) && e.target !== volumeBtn) {
                volume.classList.remove('is-visible');
            }
        });

        audio.volume = volume ? parseFloat(volume.value) : 1;
        currentVolume = audio.volume;
        audio.muted = volume ? parseFloat(volume.value) === 0 : false;
        updateVolumeIcon();


        function updateVolumeIcon() {
            if (!volumeBtn) return;
            
            if (audio.muted || audio.volume === 0) {
                
                volumeBtn.classList.add('is-muted');

            } else {
                
                volumeBtn.classList.remove('is-muted');
            }
        }

        audio.addEventListener('volumechange', function() {
            if (audio.muted) {
                if (volume) volume.value = 0;
            } else {
                if (volume) volume.value = audio.volume;
                currentVolume = audio.volume;
            }
            updateVolumeIcon();
        });

        audio.addEventListener('contextmenu', function(e) { e.preventDefault(); });

        
        audio.addEventListener('error', function(e) {
            console.error("Audio Playback Error:", e);
            
            if (time) { 
                time.textContent = "Error";
            }
            
            playBtn.disabled = true;
            progressContainer.style.pointerEvents = 'none'; 
            
            container.classList.add('cpplayer-audio-error');
        });
    });
}); 