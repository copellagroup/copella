document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.cpplayer-container').forEach(function(playerContainer) {
        const adUrl = playerContainer.dataset.videoUrl;
        if (!adUrl) return;

        const mainVideo = playerContainer.querySelector('.cpplayer-video');
        if (!mainVideo || !mainVideo.cpplayer) return;

        let adCheckInterval = null;

        function scheduleMidrollChecks() {
            if (adCheckInterval) clearInterval(adCheckInterval);
            const randomCheckInterval = (30 + Math.random() * 30) * 1000;
            adCheckInterval = setInterval(() => {
                if (playerContainer.classList.contains('ad-playing') || mainVideo.paused) return;
                const ajaxUrl = (window.cpplayer_ajax && (cpplayer_ajax.ajax_url || cpplayer_ajax.url)) || '/wp-admin/admin-ajax.php';
                const nonce = (window.cpplayer && window.cpplayer.nonce) ? `&nonce=${encodeURIComponent(window.cpplayer.nonce)}` : '';
                fetch(`${ajaxUrl}?action=cpplayer_should_play_ad&context=midroll${nonce}`)
                    .then(response => {
                        if (!response.ok) throw new Error(`HTTP ${response.status}`);
                        return response.json();
                    })
                    .then(data => {
                        if (data.success && data.data.play === true) {
                            clearInterval(adCheckInterval);
                            playVideoRoll(playerContainer, mainVideo, adUrl, scheduleMidrollChecks);
                        }
                    });
            }, randomCheckInterval);
        }

        function checkForPreroll() {
            const ajaxUrl = (window.cpplayer_ajax && (cpplayer_ajax.ajax_url || cpplayer_ajax.url)) || '/wp-admin/admin-ajax.php';
            const nonce = (window.cpplayer && window.cpplayer.nonce) ? `&nonce=${encodeURIComponent(window.cpplayer.nonce)}` : '';
            fetch(`${ajaxUrl}?action=cpplayer_should_play_ad&context=preroll${nonce}`)
                .then(response => {
                    if (!response.ok) throw new Error(`HTTP ${response.status}`);
                    return response.json();
                })
                .then(data => {
                    if (data.success && data.data.play === true) {
                        playVideoRoll(playerContainer, mainVideo, adUrl, scheduleMidrollChecks);
                    } else {
                        scheduleMidrollChecks();
                    }
                })
                .catch(() => scheduleMidrollChecks());
        }

        const mainEndedHandler = () => {
            if (adCheckInterval) clearInterval(adCheckInterval);
        };

        mainVideo.addEventListener('play', checkForPreroll, { once: true });
        mainVideo.addEventListener('ended', mainEndedHandler);
        mainVideo.__cpplayer_main_ended_handler = mainEndedHandler;
    });

    function playVideoRoll(playerContainer, mainVideo, adUrl, onAdFinishCallback) {
        if (playerContainer.classList.contains('ad-playing')) return;

        const player = mainVideo.cpplayer;
        const originalSrc = mainVideo.src;
        const originalTime = mainVideo.currentTime;
        let adSkippedOrFinished = false;
        let adDuration = 0;
        let adHls = null;
        let mainHls = playerContainer.hlsInstance;
        const videoWrapper = playerContainer.querySelector('.cpplayer-video-wrapper');
        
        const mainEndedHandler = mainVideo.__cpplayer_main_ended_handler;
        if (mainEndedHandler) {
            mainVideo.removeEventListener('ended', mainEndedHandler);
        }

        mainVideo.pause();
        player.notifyAdStarted();
        playerContainer.classList.add('ad-playing');

        let adLabel = videoWrapper ? videoWrapper.querySelector('.ad-label') : null;
        if (!adLabel) {
            adLabel = document.createElement('div');
            adLabel.className = 'ad-label';
            adLabel.textContent = 'Реклама';
            // Стили теперь задаются в CSS (style.css -> .ad-label)
            if (videoWrapper) videoWrapper.appendChild(adLabel);
        }
        let skipContainer = videoWrapper ? videoWrapper.querySelector('.ad-skip-container') : null;
        if (!skipContainer) {
            skipContainer = document.createElement('div');
            skipContainer.className = 'ad-skip-container';
            // Базовые стили для кнопки пропуска задаются в CSS
            if (videoWrapper) videoWrapper.appendChild(skipContainer);
        }
if (window && window.location && window.location.hostname && window.location.hostname.includes('localhost')) {
  console.log('[CPPLAYER] Реклама стартует!');
}

        const adSkipTimeSetting = parseInt(playerContainer.dataset.adSkipTime, 10);
        let effectiveSkipTime;

        let skipClickAttached = false;
        const COUNTDOWN_SECONDS = 3;
        
        // Create ad video overlay element
        const adVideo = document.createElement('video');
        adVideo.className = 'cpplayer-ad-video';
        adVideo.setAttribute('playsinline', '');
        adVideo.setAttribute('webkit-playsinline', '');
        adVideo.controls = false;
        adVideo.preload = 'auto';
        adVideo.style.position = 'absolute';
        adVideo.style.left = '0';
        adVideo.style.top = '0';
        adVideo.style.width = '100%';
        adVideo.style.height = '100%';
        adVideo.style.objectFit = 'contain';
        adVideo.style.background = '#000';
        adVideo.style.zIndex = '21';
        if (videoWrapper) videoWrapper.appendChild(adVideo);

        const timeUpdateHandler = () => {
            if (adSkippedOrFinished) return;
            if (isNaN(effectiveSkipTime) || effectiveSkipTime < 0) return;

            const secondsLeft = Math.ceil(effectiveSkipTime - adVideo.currentTime);

            if (secondsLeft > 0 && secondsLeft <= COUNTDOWN_SECONDS) {
                // Показать таймер за 3 секунды до появления активной кнопки
                skipContainer.classList.add('visible');
                skipContainer.innerHTML = `<span>Пропустить через ${secondsLeft}</span>`;
                skipContainer.style.pointerEvents = 'none';
                skipClickAttached = false; // сбросим на случай раннего отображения
            } else if (secondsLeft <= 0) {
                // Сделать кнопку кликабельной
                skipContainer.classList.add('visible');
                skipContainer.innerHTML = '<span>Пропустить</span>';
                skipContainer.style.pointerEvents = 'auto';
                if (!skipClickAttached) {
                    skipClickAttached = true;
                    skipContainer.addEventListener('click', finishAd, { once: true });
                }
                // Можно отключить обработчик таймера
                adVideo.removeEventListener('timeupdate', timeUpdateHandler);
            } else {
                // Рано для показа
                skipContainer.classList.remove('visible');
                skipContainer.style.pointerEvents = 'none';
            }
        };

        const adMetadataLoaded = () => {
            adDuration = adVideo.duration;
            if (adDuration > 0 && adDuration < 10) {
                effectiveSkipTime = 5;
            } else {
                effectiveSkipTime = adSkipTimeSetting;
            }
            adVideo.addEventListener('timeupdate', timeUpdateHandler);
        };
        
        const finishAd = () => {
            if (adSkippedOrFinished) return;
            adSkippedOrFinished = true;

            adVideo.removeEventListener('ended', finishAd);
            adVideo.removeEventListener('timeupdate', timeUpdateHandler);
            adVideo.removeEventListener('loadedmetadata', adMetadataLoaded);
            adVideo.removeEventListener('error', finishAd);
            
            if (adHls) {
                adHls.destroy();
                adHls = null;
            }

            playerContainer.classList.remove('ad-playing');
            if (adLabel && adLabel.remove) adLabel.remove();
            if (skipContainer && skipContainer.remove) skipContainer.remove();

            // Remove ad video overlay
            if (adVideo && adVideo.parentNode) {
                try { adVideo.pause(); } catch(e) {}
                adVideo.parentNode.removeChild(adVideo);
            }

            // Resume main video without reloading to preserve its buffer
            try { mainVideo.currentTime = originalTime > 1 ? originalTime : 0; } catch(e) {}
            player.notifyAdEnded();
            if (mainEndedHandler) {
                mainVideo.addEventListener('ended', mainEndedHandler);
            }
            const playPromise = player.playMainVideo();
            if (playPromise && typeof playPromise.catch === 'function') {
                playPromise.catch(error => {
                    console.error("CP Player: Ошибка воспроизведения основного видео после рекламы:", error);
                });
            }
            if (onAdFinishCallback) {
                onAdFinishCallback();
            }
        };

        adVideo.addEventListener('loadedmetadata', adMetadataLoaded, { once: true });
        adVideo.addEventListener('ended', finishAd);
        adVideo.addEventListener('error', finishAd);

        if (adUrl.includes('.m3u8')) {
            if (window.Hls && Hls.isSupported()) {
                adHls = new Hls();
                adHls.loadSource(adUrl);
                adHls.attachMedia(adVideo);
                adHls.on(Hls.Events.ERROR, function(event, data) {
                    if (data.fatal) {
                        finishAd();
                    }
                });
            } else if (adVideo.canPlayType('application/vnd.apple.mpegurl')) {
                adVideo.src = adUrl;
            }
        } else {
            adVideo.src = adUrl;
        }

        const adPlayPromise = adVideo.play();
        if (adPlayPromise !== undefined) {
            adPlayPromise.catch(() => {
                if (window && window.location && window.location.hostname && window.location.hostname.includes('localhost')) {
                  console.log("CP Player: Не удалось воспроизвести рекламу, возвращаемся к основному видео.");
                }
                finishAd();
            });
        }
    }
});

function reinitVideoRolls(playerContainer) {
    if (playerContainer.dataset.type === 'stream') {
        return;
    }
    const adUrl = playerContainer.dataset.videoUrl;
    if (!adUrl) return;

    const mainVideo = playerContainer.querySelector('.cpplayer-video');
    if (!mainVideo || !mainVideo.cpplayer) return;

    let adCheckInterval = null;

    function scheduleMidrollChecks() {
        if (adCheckInterval) clearInterval(adCheckInterval);
        const randomCheckInterval = (30 + Math.random() * 30) * 1000;
        adCheckInterval = setInterval(() => {
            if (playerContainer.classList.contains('ad-playing') || mainVideo.paused) return;
            fetch(cpplayer_ajax.ajax_url + '?action=cpplayer_should_play_ad&context=midroll')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.data.play === true) {
                        clearInterval(adCheckInterval);
                        playVideoRoll(playerContainer, mainVideo, adUrl, scheduleMidrollChecks);
                    }
                });
        }, randomCheckInterval);
    }

    function checkForPreroll() {
        fetch(cpplayer_ajax.ajax_url + '?action=cpplayer_should_play_ad&context=preroll')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.data.play === true) {
                    playVideoRoll(playerContainer, mainVideo, adUrl, scheduleMidrollChecks);
                } else {
                    scheduleMidrollChecks();
                }
            })
            .catch(() => scheduleMidrollChecks());
    }

    const mainEndedHandler = () => {
        if (adCheckInterval) clearInterval(adCheckInterval);
    };

    mainVideo.addEventListener('play', checkForPreroll, { once: true });
    mainVideo.addEventListener('ended', mainEndedHandler);
    mainVideo.__cpplayer_main_ended_handler = mainEndedHandler;
} 