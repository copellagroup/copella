document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.cpplayer-reset-stats-btn').forEach(function(btn) {
        btn.addEventListener('click', function() {
            if (!confirm('Сбросить статистику для этого плеера?')) return;
            var pid = btn.getAttribute('data-player-id');
            btn.disabled = true;
            btn.textContent = 'Сброс...';
            fetch(window.ajaxurl || '/wp-admin/admin-ajax.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=cpplayer_reset_stream_stats&id=' + encodeURIComponent(pid)
            })
            .then(r => r.json())
            .then(data => {
                btn.disabled = false;
                btn.textContent = 'Сбросить статистику';
                if (data.success) {
                    alert('Статистика сброшена!');
                    location.reload();
                } else {
                    alert('Ошибка: ' + (data.data && data.data.error ? data.data.error : 'Неизвестно'));
                }
            });
        });
    });
}); 