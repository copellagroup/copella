
(function(){
    try {
        var isLegacy = false;
        if (!('classList' in document.documentElement)) isLegacy = true;
        if (!('requestAnimationFrame' in window)) isLegacy = true;
        var testDiv = document.createElement('div');
        testDiv.style.display = 'flex';
        if (testDiv.style.display !== 'flex') isLegacy = true;
        if (isLegacy) {
            document.querySelectorAll('.cpplayer-container').forEach(function(container){
                container.classList.add('cpplayer-legacy');
                var video = container.querySelector('video');
        if (video) video.controls = true;
            });
            return; 
        }
  } catch(e) {}
    
  try {
    var topProgressBar = document.createElement('div');
    topProgressBar.className = 'cpplayer-top-page-loader';
    topProgressBar.style.transition = 'width 0.25s ease-out';
    document.body.appendChild(topProgressBar);

    window.CPPlayer = window.CPPlayer || {};
    (function(){
      var active = false;
      var hideTimeout = null;
      function ensureVisible() {
        if (!topProgressBar.parentNode) {
          document.body.appendChild(topProgressBar);
        }
      }
      function start() {
        ensureVisible();
        if (hideTimeout) { clearTimeout(hideTimeout); hideTimeout = null; }
        active = true;
        topProgressBar.style.width = '0%';
        requestAnimationFrame(function(){
          topProgressBar.style.width = '60%';
        });
      }
      function set(percent) {
        if (!active) start();
        var p = Math.max(0, Math.min(100, percent));
        topProgressBar.style.width = p + '%';
      }
      function done() {
        if (!active) return;
        topProgressBar.style.width = '100%';
        hideTimeout = setTimeout(function(){
          active = false;
          topProgressBar.style.width = '0%';
        }, 350);
      }
      window.CPPlayer.topLoader = { start: start, set: set, done: done };
    })();
  } catch(e) {}

  function start() {
    if (window.CPPlayer && typeof CPPlayer.initPlayers === 'function') {
      CPPlayer.initPlayers();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
                } else {
    start();
  }
})();
