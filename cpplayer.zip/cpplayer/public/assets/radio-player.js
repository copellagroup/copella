document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.cpplayer-container.cpplayer-radio').forEach(function(container) {
        const audio = container.querySelector('.cpplayer-radio-el');
        const playBtn = container.querySelector('.cpplayer-play');
        const volume = container.querySelector('.cpplayer-volume');
        const volumeBtn = container.querySelector('.cpplayer-volume-btn');
        const statusEl = container.querySelector('.cpplayer-radio-status');
        let currentVolume = 1; 

        function setStatus(text, isLive) {
            if (statusEl) {
                statusEl.textContent = text;
                statusEl.className = 'cpplayer-radio-status';
                if (isLive) {
                    statusEl.classList.add('is-live');
                }
            }
        }

        playBtn.addEventListener('click', function() {
            if (audio.paused) {
                audio.load();
                audio.play();
            } else {
                audio.pause();
            }
        });
        audio.addEventListener('play', function() {
            playBtn.classList.add('is-playing');
            setStatus('Онлайн', true);
        });
        audio.addEventListener('pause', function() {
            playBtn.classList.remove('is-playing');
            if (audio.readyState > 0) {
                 setStatus('Пауза', true);
            }
        });

        audio.addEventListener('waiting', function() {
            setStatus('Загрузка...', false);
        });

        audio.addEventListener('canplay', function() {
             if (audio.paused) {
                 setStatus('Готово', false);
             } else {
                setStatus('Онлайн', true);
             }
        });
        audio.addEventListener('error', function() {
            setStatus('Офлайн', false);
        });
        audio.addEventListener('stalled', function() {
            setStatus('Поток недоступен', false);
        });
        audio.addEventListener('ended', function() {
            playBtn.classList.remove('is-playing');
            setStatus('Вещание завершено', false);
        });

        
        if (volume) {
            const updateVolumeFill = () => {
                const val = parseFloat(volume.value || '0');
                const percent = Math.max(0, Math.min(1, val)) * 100;
                volume.style.setProperty('--cpplayer-volume-fill', percent + '%');
            };
            updateVolumeFill();
            volume.addEventListener('input', function() {
                audio.volume = parseFloat(this.value);
                audio.muted = parseFloat(this.value) === 0;
                updateVolumeFill();
            });
        }
        
        if (volumeBtn && volume) {
            volumeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                volume.classList.toggle('is-visible');
            });
        }
        
        document.addEventListener('click', function(e) {
            if (volume && volume.classList.contains('is-visible') && !volume.contains(e.target) && e.target !== volumeBtn) {
                volume.classList.remove('is-visible');
            }
        });
        
        audio.volume = volume ? parseFloat(volume.value) : 1;
        currentVolume = audio.volume;
        audio.muted = volume ? parseFloat(volume.value) === 0 : false;
        updateVolumeIcon();


        function updateVolumeIcon() {
            if (!volumeBtn) return;
            if (audio.muted || audio.volume === 0) {
                volumeBtn.classList.add('is-muted'); 
            } else {
                volumeBtn.classList.remove('is-muted'); 
            }
        }

        audio.addEventListener('volumechange', function() {
            if (!audio.muted) {
                currentVolume = audio.volume;
                if (volume) {
                    volume.value = audio.volume;
                }
            } else {
                 if (volume) {
                    volume.value = 0;
                 }
            }
            updateVolumeIcon();
        });

        audio.addEventListener('contextmenu', function(e) { e.preventDefault(); });
    });
}); 