// seek-hint.js — UI-компонент подсказки перемотки
// Copella 2025

function showSeekHint(seekHintPopup, duration = 3000) {
  if (!seekHintPopup) return;
  clearTimeout(seekHintPopup._hintTimeout);
  seekHintPopup.classList.add('show-seek-hint');
  seekHintPopup._hintTimeout = setTimeout(() => {
    hideSeekHint(seekHintPopup);
  }, duration);
}

function hideSeekHint(seekHintPopup) {
  if (!seekHintPopup) return;
  clearTimeout(seekHintPopup._hintTimeout);
  seekHintPopup.classList.remove('show-seek-hint');
}

function showInitialRandomHint(seekHintPopup) {
  const delay = 5000 + Math.random() * 10000;
  setTimeout(() => {
    if (seekHintPopup && !seekHintPopup.classList.contains('show-seek-hint')) {
      seekHintPopup.classList.add('show-seek-hint');
      setTimeout(() => {
        if (seekHintPopup) seekHintPopup.classList.remove('show-seek-hint');
      }, 5000);
    }
  }, delay);
}

function createSeekHintElement(text = 'Перемещайте, чтобы найти нужный момент') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = `
    <div class="cpplayer-seek-hint-popup">
      <div class="cpplayer-seek-thumbnail-container">
        <img src="" class="cpplayer-seek-thumbnail" alt="Preview">
      </div>
      <div class="cpplayer-seek-time-indicator">00:00</div>
      <span class="hint-text">${text}</span>
    </div>
  `;
  return wrapper.firstElementChild;
}

window.createSeekHintElement = createSeekHintElement;
window.showSeekHint = showSeekHint;
window.hideSeekHint = hideSeekHint;
window.showInitialRandomHint = showInitialRandomHint; 