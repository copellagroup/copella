<?php
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: #000;
        }
        #cpplayer_embed_container {
            width: 100%;
            height: 100%;
        }
    </style>
</head>
<body>
    <div id="cpplayer_embed_container">
        <?php
        $video_url = isset($_GET['src']) ? esc_url_raw($_GET['src']) : '';
        if ($video_url) {
            echo do_shortcode('[cpplayer src="' . $video_url . '"]');
        } else {
            echo '<p style="color: white; text-align: center; padding-top: 20px;">' . __('Источник видео не указан.', 'cpplayer') . '</p>';
        }
        ?>
    </div>
    <?php wp_footer(); ?>
</body>
</html> 