<?php
if (!defined('ABSPATH')) exit;


if (!function_exists('cpplayer_get_post_views')) {
    function cpplayer_get_post_views($post_id) {
        if (!$post_id) return 0;
        $views = 0;
        $meta_keys = ['views', 'post_views_count', 'wp_statistics_visits', '_views'];
        foreach ($meta_keys as $key) {
            $v = get_post_meta($post_id, $key, true);
            if ($v !== '' && is_numeric($v)) {
                $views = max($views, intval($v));
            }
        }
        return $views;
    }
}

function cpplayer_get_mime_type($src) {
    $ext = strtolower(pathinfo(parse_url($src, PHP_URL_PATH), PATHINFO_EXTENSION));
    switch ($ext) {
        case 'm3u8': return 'application/vnd.apple.mpegurl';
        case 'mp4': return 'video/mp4';
        case 'webm': return 'video/webm';
        case 'ogv': return 'video/ogg';
        case 'ts': return 'video/mp2t';
        default: return '';
    }
}

add_shortcode('cpplayer', function($atts) {
    $atts = shortcode_atts([
        'id' => '',
        'src' => '',
        'title' => '',
        'video_id' => '',
        'poster' => '',
    ], $atts, 'cpplayer');

    $id = $atts['id'];
    $src_attr = $atts['src'];
    $title_attr = $atts['title'];
    $player_data = null;

    if (!empty($src_attr)) {
        $player_data = [
            'src' => $src_attr,
            'title' => !empty($title_attr) ? $title_attr : 'Video',
            'type' => 'video',
            'author' => '',
            'image' => '',
            'radio_logo' => ''
        ];
    } else {
        if (empty($id) && get_the_ID()) {
            $id = get_the_ID();
        }

        if (empty($id)) {
            return __('Не указан ID.', 'cpplayer');
        }

        $players = get_option('cpplayer_shortcodes', []);
        
        if (isset($players[$id])) {
            $player_data = $players[$id];
        } else if (is_numeric($id)) {
            $post_content = get_post_field('post_content', $id);
            if ($post_content && preg_match('/\[cpplayer id="([^"]+)"\]/', $post_content, $matches)) {
                $player_id_from_content = $matches[1];
                if (isset($players[$player_id_from_content])) {
                    $player_data = $players[$player_id_from_content];
                }
            }
        }
    }

    if (!$player_data) {
        return __('Плеер не найден.', 'cpplayer');
    }
    
    $src = esc_url($player_data['src']);
    $title = esc_html($player_data['title']);
    $type = $player_data['type'] ?? 'video';
    $author = $player_data['author'] ?? '';
    $image = $player_data['image'] ?? '';
    $radio_logo = $player_data['radio_logo'] ?? '';
    
    $stub_video_url = get_option('cpplayer_stub_video_url');
    if (empty($stub_video_url)) {
        $stub_video_url = 'https://copella.live/id.mp4';
    }
    $ad_skip_time = get_option('cpplayer_ad_skip_time', 5);

    $video_url = '';
    $all_videos = get_option('cpplayer_videos', []);
    if (!empty($all_videos)) {
        $random_video_key = array_rand($all_videos);
        if (isset($all_videos[$random_video_key]['url'])) {
            $video_url = $all_videos[$random_video_key]['url'];
        }
    }

    $video_id = $atts['video_id'];
    if ($video_id) {
        $video_url = wp_get_attachment_url($video_id);
    }

    $vtt_url = $video_id ? get_post_meta($video_id, '_cpplayer_vtt_url', true) : '';
    $data_attributes = $vtt_url ? ' data-thumbnails-vtt="' . esc_url($vtt_url) . '"' : '';

    $poster = $atts['poster'] ? ' poster="' . esc_url($atts['poster']) . '"' : '';
    $title_attr = $atts['title'] ? ' data-title="' . esc_attr($atts['title']) . '"' : '';

    $ver = intval(get_option('cpplayer_cache_version', 1));
    $ver = max(1, $ver);

    $is_embed = isset($_GET['embed']) && $_GET['embed'] === 'true';

    ob_start();

    if ($is_embed) {
    ?>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            background-color: #000;
        }
        .cpplayer-container {
            width: 100% !important;
            height: 100% !important;
            max-width: none !important;
            border-radius: 0 !important;
        }
        .cpplayer-video-wrapper {
            height: 100% !important;
            padding-top: 0 !important;
            border-radius: 0 !important;
        }
        .cpplayer-video {
            border-radius: 0 !important;
            object-fit: contain !important;
        }
        .cpplayer-title {
            display: none !important;
        }
    </style>
    <?php
    }
    ?>
    <?php if ($type === 'audio'): ?>
    <div class="cpplayer-container cpplayer-audio" data-type="audio" data-id="<?= $id ?>" data-title="<?= $title ?>" data-author="<?= $author ?>" data-image="<?= $image ?>" data-src="<?= $src ?>">
        <audio class="cpplayer-audio-el" src="<?= $src ?>" preload="metadata"></audio>
        <div class="cpplayer-audio-bg" style="<?= $image ? 'background-image:url(' . $image . ')' : '' ?>"></div>
        <div class="cpplayer-audio-controls">
            <button class="cpplayer-play" title="Play/Pause">
                <svg class="play-icon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"></path></svg>
                <svg class="pause-icon" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"></path></svg>
            </button>
            <div class="cpplayer-audio-info">
                <div class="cpplayer-audio-title"><?= $title ?></div>
                <div class="cpplayer-audio-author"><?= $author ?></div>
            </div>
            <div class="cpplayer-audio-progress-container">
                <div class="cpplayer-audio-progress"></div>
                <div class="cpplayer-audio-buffer"></div>
            </div>
            <div class="cpplayer-audio-time">00:00 / 00:00</div>
            
            <button class="cpplayer-volume-btn" title="<?= __('Volume', 'cpplayer') ?>">
                <svg class="cpplayer-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                    <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                </svg>
            </button>
            <input type="range" class="cpplayer-volume" min="0" max="1" step="0.01" value="1">
            
            <div class="cpplayer-progress">
                <div class="cpplayer-progress-buffer"></div>
                <div class="cpplayer-progress-played"></div>
            </div>
            <span class="cpplayer-time"></span>
            <button class="cpplayer-fullscreen" title="<?= __('Fullscreen', 'cpplayer') ?>">
                <img src="<?= plugins_url('public/assets/icon-fullscreen.svg', __DIR__ . '/../..') ?>" alt="Fullscreen">
            </button>
        </div>
    </div>
    <?php elseif ($type === 'radio'): ?>
    <div class="cpplayer-container cpplayer-radio" data-src="<?= $src ?>" data-title="<?= $title ?>" data-logo="<?= $radio_logo ?>">
        <audio class="cpplayer-radio-el" src="<?= $src ?>" preload="none"></audio>
        <div class="cpplayer-radio-logo">
            <img src="<?= $radio_logo ?>" alt="<?= $title ?>">
        </div>
        <div class="cpplayer-radio-info">
            <div class="cpplayer-radio-title"><?= $title ?></div>
            <div class="cpplayer-radio-status"></div>
        </div>
        <button class="cpplayer-play" title="Play/Pause">
            <svg class="play-icon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            <svg class="pause-icon" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></path></svg>
        </button>
        <div class="cpplayer-volume-container">
            <button class="cpplayer-volume-btn" title="Volume">
                <svg class="volume-icon" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"></path></svg>
            </button>
            <input type="range" class="cpplayer-volume" min="0" max="1" step="0.01" value="0.8">
        </div>
    </div>
    <?php elseif ($type === 'stream'): ?>
    <div class="cpplayer-container" data-type="stream" data-share-src="<?= esc_attr($src) ?>" data-video-url="<?= esc_attr($video_url) ?>" data-ad-skip-time="<?= esc_attr($ad_skip_time) ?>">
        <div class="cpplayer-video-wrapper">
            <div class="cpplayer-ad-container"></div>
            <video id="cpplayer-video-<?= $id ?>" class="cpplayer-video" preload="metadata" playsinline data-src="<?= esc_attr($src) ?>"></video>
            <div class="cpplayer-title"><?= $title ?></div>
            <div class="cpplayer-stream-stub" style="display:none;position:absolute;top:0;left:0;width:100%;height:100%;background:#000;align-items:center;justify-content:center;z-index:10;color:#fff;font-size:1.2em;flex-direction:column;">
                <?php if (!empty($stub_video_url)): ?>
                <video src="<?= esc_url($stub_video_url) ?>" autoplay muted loop playsinline style="width:100%;height:100%;object-fit:cover;"></video>
                <?php endif; ?>
                <button class="cpplayer-stub-volume-btn" title="Включить звук" style="position:absolute;right:20px;bottom:20px;z-index:100;width:36px;height:36px;background:rgba(0,0,0,0.7);border:none;border-radius:50%;display:flex;align-items:center;justify-content:center;">
                    <span style="display:flex;align-items:center;justify-content:center;width:100%;height:100%;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon></svg>
                    </span>
                </button>
            </div>
            <div class="cpplayer-controls" data-for="cpplayer-video-<?= $id ?>">
                <button class="cpplayer-play" title="<?= __('Play/Pause', 'cpplayer') ?>">
                    <img src="<?= plugins_url('public/assets/icon-play.svg', __DIR__ . '/../..') ?>" alt="Play" class="cpplayer-icon cpplayer-icon-play">
                    <img src="<?= plugins_url('public/assets/icon-pause.svg', __DIR__ . '/../..') ?>" alt="Pause" class="cpplayer-icon cpplayer-icon-pause">
                </button>
                <div class="cpplayer-progress">
                  <div class="cpplayer-progress-buffer"></div>
                  <div class="cpplayer-progress-played"></div>
                </div>
                <span class="cpplayer-time"></span>
                <div class="cpplayer-volume-container">
                    <button class="cpplayer-volume-btn" title="<?= __('Volume', 'cpplayer') ?>">
                        <img src="<?= plugins_url('public/assets/icon-volume.svg', __DIR__ . '/../..') ?>" alt="Volume">
                    </button>
                    <input type="range" class="cpplayer-volume" min="0" max="1" step="0.01" value="1">
                </div>
                <button class="cpplayer-fullscreen" title="<?= __('Fullscreen', 'cpplayer') ?>">
                    <img src="<?= plugins_url('public/assets/icon-fullscreen.svg', __DIR__ . '/../..') ?>" alt="Fullscreen">
                </button>
            </div>
        </div>
        <div class="cpplayer-likes-container">
            <button class="cpplayer-heart-btn" title="Поставить лайк">
                <svg class="cpplayer-heart-icon" width="22" height="22" viewBox="0 0 24 24">
                  <path class="cpplayer-heart-shape" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 6.01 4.01 4 6.5 4c1.74 0 3.41 1.01 4.13 2.44h.74C14.09 5.01 15.76 4 17.5 4 19.99 4 22 6.01 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                </svg>
            </button>
            <span class="cpplayer-heart-count" data-skeleton="true">&nbsp;</span>
        </div>
    </div>
    <script src="<?= plugins_url('public/assets/stream-player.js', __DIR__ . '/../..') ?>?ver=<?= $ver ?>"></script>
    <?php elseif ($type === 'video'): ?>
    <div class="cpplayer-container" data-type="video" data-share-src="<?= esc_attr($src) ?>" data-video-url="<?= esc_attr($video_url) ?>" data-ad-skip-time="<?= esc_attr($ad_skip_time) ?>">
        <div class="cpplayer-video-wrapper">
            <div class="cpplayer-ad-container"></div>
            <video id="cpplayer-video-<?= $id ?>" class="cpplayer-video" preload="metadata" playsinline<?= $poster ?> >
                <source src="<?= esc_attr($src) ?>" type="<?= esc_attr(cpplayer_get_mime_type($src)) ?>">
            </video>
            <div class="cpplayer-title"><?= $title ?></div>
            <div class="cpplayer-controls" data-for="cpplayer-video-<?= $id ?>">
                <button class="cpplayer-play" title="<?= __('Play/Pause', 'cpplayer') ?>">
                    <img src="<?= plugins_url('public/assets/icon-play.svg', __DIR__ . '/../..') ?>" alt="Play" class="cpplayer-icon cpplayer-icon-play">
                    <img src="<?= plugins_url('public/assets/icon-pause.svg', __DIR__ . '/../..') ?>" alt="Pause" class="cpplayer-icon cpplayer-icon-pause">
                </button>
                <div class="cpplayer-volume-container">
                    <button class="cpplayer-volume-btn" title="<?= __('Volume', 'cpplayer') ?>">
                        <img src="<?= plugins_url('public/assets/icon-volume.svg', __DIR__ . '/../..') ?>" alt="Volume">
                    </button>
                    <input type="range" class="cpplayer-volume" min="0" max="1" step="0.01" value="1">
                </div>
                <span class="cpplayer-time">00:00 / 00:00</span>
                <div class="cpplayer-progress">
                  <div class="cpplayer-progress-buffer"></div>
                  <div class="cpplayer-progress-played"></div>
                </div>
                <button class="cpplayer-fullscreen" title="<?= __('Fullscreen', 'cpplayer') ?>">
                    <img src="<?= plugins_url('public/assets/icon-fullscreen.svg', __DIR__ . '/../..') ?>" alt="Fullscreen">
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <style>
        .cpplayer-ad-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: #000;
            z-index: 20;
            display: none;
        }
        .cpplayer-ad-container video {
            width: 100%;
            height: 100%;
        }
        /* Hide title during ads; keep using the runtime class 'ad-playing' */
        .cpplayer-container.ad-playing .cpplayer-title {
            display: none !important;
        }

        .cpplayer-ad-container .ad-controls {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(to top, rgba(0,0,0,0.7), transparent);
            padding: 10px;
            box-sizing: border-box;
            display: flex;
            align-items: center;
            gap: 15px;
            z-index: 22;
        }

        .cpplayer-ad-container .ad-progress-bar {
            position: absolute;
            bottom: 45px; 
            left: 10px;
            right: 10px;
            height: 4px;
            background-color: rgba(255, 255, 255, 0.3);
            cursor: pointer;
        }

        .cpplayer-ad-container .ad-progress-played {
            width: 0;
            height: 100%;
            background-color: #ffcc00; 
        }

        .cpplayer-ad-container .ad-play-pause-btn,
        .cpplayer-ad-container .ad-volume-btn {
            background: none;
            border: none;
            padding: 0;
            cursor: pointer;
            width: 24px;
            height: 24px;
        }

        .cpplayer-ad-container .ad-time-display {
            color: white;
            font-size: 14px;
        }
        
        .cpplayer-ad-container .ad-center-btn {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: none;
            border: none;
            z-index: 21;
            cursor: pointer;
        }
    </style>
    <?php
    return ob_get_clean();
});

function cpplayer_should_play_ad_ajax() {
    check_ajax_referer('cpplayer_nonce', 'nonce');

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    $context = isset($_REQUEST['context']) ? sanitize_text_field($_REQUEST['context']) : 'midroll';
    $now = time();
    $last_ad_time = $_SESSION['cpplayer_last_ad_time'] ?? 0;
    $play_ad = false;

    if ($context === 'preroll') {
        $first_ad_time = $_SESSION['cpplayer_first_ad_shown_time'] ?? 0;
        if (!$first_ad_time || ($now - $first_ad_time > 1800)) {
            if (rand(1, 100) <= 70) { 
                $play_ad = true;
                $_SESSION['cpplayer_first_ad_shown_time'] = $now;
            }
        } else if ($now - $last_ad_time >= 240) { 
            if (rand(1, 100) <= 50) { 
                $play_ad = true;
            }
        }
    } else { 
        $min_interval = 240; 
        if ($now - $last_ad_time >= $min_interval) {
            if (rand(1, 100) <= 70) { 
                $play_ad = true;
            }
        }
    }

    if ($play_ad) {
        $_SESSION['cpplayer_last_ad_time'] = $now;
        $all_videos = get_option('cpplayer_videos', []);
        if (!empty($all_videos)) {
            $random_video_key = array_rand($all_videos);
            if (isset($all_videos[$random_video_key]['url'])) {
                wp_send_json_success(['play' => true, 'url' => $all_videos[$random_video_key]['url']]);
            }
        }
    }

    wp_send_json_success(['play' => false]);
}
add_action('wp_ajax_nopriv_cpplayer_should_play_ad', 'cpplayer_should_play_ad_ajax');
add_action('wp_ajax_cpplayer_should_play_ad', 'cpplayer_should_play_ad_ajax');

function cpplayer_get_next_video_ajax() {
    $args = [
        'post_type'      => 'post',
        'category_name'  => 'videos',
        'posts_per_page' => 1,
        'orderby'        => 'rand',
    ];

    if (isset($_POST['current_post_id']) && is_numeric($_POST['current_post_id'])) {
        $args['post__not_in'] = [intval($_POST['current_post_id'])];
    }

    $next_post_query = new WP_Query($args);

    if ($next_post_query->have_posts()) {
        $next_post_query->the_post();
        $post_id = get_the_ID();
        
        $content = get_the_content();
        $src = '';
        $player_title = get_the_title(); 

        if (preg_match('/\[cpplayer id="([^"]+)"\]/', $content, $matches)) {
            $player_id = $matches[1];
            $players = get_option('cpplayer_shortcodes', []);
            if (isset($players[$player_id])) {
                $player_data = $players[$player_id];
                $src = $player_data['src'];
                if (!empty($player_data['title'])) {
                    $player_title = $player_data['title'];
                }
            }
        }
        
        $thumbnail_url = get_the_post_thumbnail_url($post_id, 'large');
        if (!$thumbnail_url) {
            $thumbnail_url = plugins_url('public/assets/placeholder.png', __DIR__ . '/../..');
        }

        wp_reset_postdata();

        if (!empty($src)) {
            wp_send_json_success([
                'id'        => $post_id,
                'url'       => get_permalink($post_id),
                'title'     => $player_title,
                'thumbnail' => $thumbnail_url,
                'src'       => $src,
            ]);
        } else {
            wp_send_json_error(['message' => 'Не нашлось видео для показа.']);
        }

    } else {
        wp_send_json_error(['message' => 'No more videos found.']);
    }
}
add_action('wp_ajax_cpplayer_get_next_video', 'cpplayer_get_next_video_ajax');
add_action('wp_ajax_nopriv_cpplayer_get_next_video', 'cpplayer_get_next_video_ajax');

function cpplayer_stream_stat_ajax() {
    if (!isset($_POST['id']) || !isset($_POST['stat_action'])) {
        wp_send_json_error(['message' => 'Missing parameters.'], 400);
    }

    $player_id = sanitize_text_field($_POST['id']);
    $action = sanitize_text_field($_POST['stat_action']);

    $stats = get_transient('cpplayer_stats_' . $player_id);
    if (false === $stats) {
        $stats = ['likes' => 0, 'views' => 0];
    }

    if ($action === 'get') {
        wp_send_json_success($stats);
    }

    $ip = $_SERVER['REMOTE_ADDR'];
    $transient_key = 'cpplayer_like_' . $player_id . '_' . md5($ip);

    if ($action === 'like') {
        if (get_transient($transient_key)) {
            wp_send_json_error(['message' => 'You have already liked this.'], 403);
        }
        $stats['likes'] = intval($stats['likes']) + 1;
        set_transient($transient_key, 1, DAY_IN_SECONDS);
    } elseif ($action === 'unlike') {
        if (!get_transient($transient_key)) {
            wp_send_json_error(['message' => 'You have not liked this yet.'], 403);
        }
        $stats['likes'] = max(0, intval($stats['likes']) - 1);
        delete_transient($transient_key);
    } else {
        wp_send_json_error(['message' => 'Invalid action.'], 400);
    }

    set_transient('cpplayer_stats_' . $player_id, $stats, WEEK_IN_SECONDS);

    wp_send_json_success($stats);
}
add_action('wp_ajax_cpplayer_stream_stat', 'cpplayer_stream_stat_ajax');
add_action('wp_ajax_nopriv_cpplayer_stream_stat', 'cpplayer_stream_stat_ajax');