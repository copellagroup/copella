<?php
/*
Plugin Name: CP Player
Description: Кастомный видео плеер для WordPress, разработан для платформы copella.live. Современный дизайн, поддержка любых ссылок, управление шорткодами через админку. Все элементы на русском языке.
Version: 2.4
Author: Copella
Text Domain: cpplayer
Domain Path: /languages
*/


if (!defined('ABSPATH')) exit;


require_once plugin_dir_path(__FILE__) . 'public/player-shortcode.php';
require_once plugin_dir_path(__FILE__) . 'admin/admin-page.php';



function cpplayer_enqueue_scripts() {
    
    if (is_admin()) {
        return;
    }

    $should_enqueue = false;
    $post = get_post();
    if ($post && isset($post->post_content)) {
        $should_enqueue = has_shortcode($post->post_content, 'cpplayer');
    }

    if (!$should_enqueue) {
        $should_enqueue = is_page_template('public/embed-template.php') || (isset($_GET['embed']) && $_GET['embed'] === 'true');
    }

    if (!$should_enqueue) {
        return;
    }
    $ver = intval(get_option('cpplayer_cache_version', 1));
    $ver = max(1, $ver);
    wp_enqueue_style('cpplayer-style', plugins_url('public/assets/style.css', __FILE__), [], $ver);
    wp_enqueue_style('seek-hint-css', plugins_url('/public/ui/seek-hint/seek-hint.css', __FILE__), [], $ver);
    wp_enqueue_script('hls-js', 'https://cdn.jsdelivr.net/npm/hls.js@1.6.5', [], null, true);
    wp_enqueue_script('seek-hint-js', plugins_url('/public/ui/seek-hint/seek-hint.js', __FILE__), [], $ver, true);

    // Modular player scripts (loaded before bootstrap)
    wp_enqueue_script('cpplayer-dom-utils-js', plugins_url('public/assets/player/dom-utils.js', __FILE__), [], $ver, true);
    wp_enqueue_script('cpplayer-format-time-js', plugins_url('public/assets/player/format-time.js', __FILE__), [], $ver, true);
    wp_enqueue_script('cpplayer-state-js', plugins_url('public/assets/player/state.js', __FILE__), [], $ver, true);
    wp_enqueue_script('cpplayer-hls-utils-js', plugins_url('public/assets/player/hls-utils.js', __FILE__), ['hls-js'], $ver, true);
    wp_enqueue_script('cpplayer-init-players-js', plugins_url('public/assets/player/init-players.js', __FILE__), ['cpplayer-dom-utils-js','cpplayer-format-time-js','cpplayer-state-js','cpplayer-hls-utils-js','seek-hint-js'], $ver, true);
    wp_enqueue_script('cpplayer-wire-player-js', plugins_url('public/assets/player/wire-player.js', __FILE__), ['cpplayer-init-players-js'], $ver, true);
    
    // Main bootstrap (keeps the original handle 'cpplayer-js' to satisfy existing dependencies)
    wp_enqueue_script('cpplayer-js', plugins_url('public/assets/player.js', __FILE__), ['cpplayer-wire-player-js'], $ver, true);
    
    wp_enqueue_script('cpplayer-video-rolls-js', plugins_url('public/assets/video-rolls.js', __FILE__), ['cpplayer-js'], $ver, true);

    wp_localize_script('cpplayer-js', 'cpplayer_ajax', [
        'url' => admin_url('admin-ajax.php'),
    ]);
    wp_localize_script('cpplayer-video-rolls-js', 'cpplayer_ajax', [
        'url' => admin_url('admin-ajax.php'),
    ]);

    // Removed enqueue of non-existent player.css; main styles are in style.css above.

    wp_enqueue_style('cpplayer-audio-style', plugins_url('public/assets/audio-player.css', __FILE__), [], $ver);
    wp_enqueue_script('cpplayer-audio-js', plugins_url('public/assets/audio-player.js', __FILE__), [], $ver, true);
    wp_enqueue_style('cpplayer-radio-style', plugins_url('public/assets/radio-player.css', __FILE__), [], $ver);
    wp_enqueue_script('cpplayer-radio-js', plugins_url('public/assets/radio-player.js', __FILE__), [], $ver, true);

    wp_localize_script('cpplayer-js', 'cpplayer', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('cpplayer_nonce'),
        'ad_skip_time' => get_option('cpplayer_ad_skip_time', 5),
        'embed_url' => get_option('cpplayer_embed_page_id') ? get_permalink(get_option('cpplayer_embed_page_id')) : ''
    ]);
}
add_action('wp_enqueue_scripts', 'cpplayer_enqueue_scripts');


add_action('plugins_loaded', function() {
    load_plugin_textdomain('cpplayer', false, dirname(plugin_basename(__FILE__)) . '/languages');
});

add_action('wp_ajax_nopriv_cpplayer_should_play_ad', 'cpplayer_should_play_ad_ajax');
add_action('wp_ajax_cpplayer_should_play_ad', 'cpplayer_should_play_ad_ajax');

function cpplayer_add_embed_template($templates) {
    $templates['public/embed-template.php'] = __('CP Player Embed', 'cpplayer');
    return $templates;
}
add_filter('theme_page_templates', 'cpplayer_add_embed_template');

function cpplayer_load_embed_template($template) {
    if (is_page_template('public/embed-template.php')) {
        $plugin_template = plugin_dir_path(__FILE__) . 'public/embed-template.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }
    return $template;
}
add_filter('template_include', 'cpplayer_load_embed_template');
